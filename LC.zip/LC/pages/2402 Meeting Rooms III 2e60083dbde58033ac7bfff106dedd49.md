# 2402. Meeting Rooms III

LeetCode URL: https://leetcode.com/problems/meeting-rooms-iii
Approach: Sort the meetings array with starttime. Create a MinHeap for available rooms. Create a MinHeap for object:- PriorityQueue<RoomInfo> usedRooms. Store meetingEndtime, RoomNo. Finally a freqMap for counting the room which is used most times.
Coding Pattern: Two Heaps
Company: Amazon, Google, Meta
Date Solved: January 16, 2026
Difficulty Level: Hard
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(MlogM+MlogN+NlogN)
Space Complexity: O(N+sort)
Topic: Arrays, Heap (Priority Queue)

### 🐞 Problem Statement

You are given an integer `n`. There are `n` rooms numbered from `0` to `n - 1`.

You are given a 2D integer array `meetings` where `meetings[i] = [starti, endi]` means that a meeting will be held during the **half-closed** time interval `[starti, endi)`. All the values of `starti` are **unique**.

Meetings are allocated to rooms in the following manner:

1. Each meeting will take place in the unused room with the **lowest** number.
2. If there are no available rooms, the meeting will be delayed until a room becomes free. The delayed meeting should have the **same** duration as the original meeting.
3. When a room becomes unused, meetings that have an earlier original **start** time should be given the room.

Return *the **number** of the room that held the most meetings.* If there are multiple rooms, return *the room with the **lowest** number.*

A **half-closed interval** `[a, b)` is the interval between `a` and `b` **including** `a` and **not including** `b`.

**Example 1:**

```
Input: n = 2, meetings = [[0,10],[1,5],[2,7],[3,4]]
Output: 0
Explanation:
- At time 0, both rooms are not being used. The first meeting starts in room 0.
- At time 1, only room 1 is not being used. The second meeting starts in room 1.
- At time 2, both rooms are being used. The third meeting is delayed.
- At time 3, both rooms are being used. The fourth meeting is delayed.
- At time 5, the meeting in room 1 finishes. The third meeting starts in room 1 for the time period [5,10).
- At time 10, the meetings in both rooms finish. The fourth meeting starts in room 0 for the time period [10,11).
Both rooms 0 and 1 held 2 meetings, so we return 0.
```

**Example 2:**

```
Input: n = 3, meetings = [[1,20],[2,10],[3,5],[4,9],[6,8]]
Output: 1
Explanation:
- At time 1, all three rooms are not being used. The first meeting starts in room 0.
- At time 2, rooms 1 and 2 are not being used. The second meeting starts in room 1.
- At time 3, only room 2 is not being used. The third meeting starts in room 2.
- At time 4, all three rooms are being used. The fourth meeting is delayed.
- At time 5, the meeting in room 2 finishes. The fourth meeting starts in room 2 for the time period [5,10).
- At time 6, all three rooms are being used. The fifth meeting is delayed.
- At time 10, the meetings in rooms 1 and 2 finish. The fifth meeting starts in room 1 for the time period [10,12).
Room 0 held 1 meeting while rooms 1 and 2 each held 2 meetings, so we return 1.
```

**Constraints:**

- `1 <= n <= 100`
- `1 <= meetings.length <= 105`
- `meetings[i].length == 2`
- `0 <= starti < endi <= 5 * 105`
- All the values of `starti` are **unique**.

---

### 🧮 Approach / Algorithm Design

## **Solution**

---

### **Overview**

This problem involves the efficient allocation of meeting rooms to a set of scheduled meetings, each defined by a start and end time. The goal is to determine the room number that hosts the maximum number of meetings. If multiple rooms hold the same maximum number of meetings, the solution should return the room with the lowest number. By addressing this problem, algorithms developed for this type of scheduling challenge can be adapted to improve efficiency in real-world scenarios where resource allocation and scheduling are essential components.

### **Approach 2: Sorting, Counting using Priority Queues**

### **Intuition**

In the preceding solution, the iteration over all *N* rooms occurs within the nested loop, resulting in an overall time complexity of *O*(*M*⋅*N*) for the `for` loop. To enhance efficiency we must explore avenues for optimization. We need to devise a method to obtain the next available room without the necessity of iterating over all *N* rooms. To do this we can maintain two crucial structures: `unused_rooms` and `used_rooms.` These structures are essentially priority queues or heaps, with `unused_rooms` representing available rooms sorted by room number, and `used_rooms` storing rooms in use along with the time they become available again.

We start by initialization of `unused_rooms` as a priority queue containing all room numbers and `used_rooms` as an empty priority queue.

`unused_rooms` is ordered in ascending order according to room numbers. This arrangement guarantees that when an element is popped from this, it returns the unused room with the lowest number. This is important to follow rule 1, which states that each meeting will take place in the unused room with the lowest number.

`used_rooms` is a priority queue that contains elements in the form of `{room_availability_time, room_number}`. Here, `room_availability_time` signifies the time at which this room becomes unused. This priority queue is ordered in ascending order based on both `room_availability_time` and `room_number`. This ensures that when an element is popped from it, the room returned is the one that becomes unused earliest. This assists in adhering to rules 2 and 3 while allocating a meeting to the room that becomes unused earliest when all rooms are currently in use.

Then we proceed to iterate through the meetings after sorting them based on their start times, adhering to the rule that meetings should be allocated based on their start times. Within this loop, a cascading series of decisions unfolds to handle various scenarios.

When iterating through meetings we first manage the release of rooms that have become unused. We iterate through `used_rooms`, popping rooms from the heap if their availability time is earlier than or equal to the start time of the current meeting. Released rooms are then pushed into `unused_rooms`.

Subsequently, we check if there are available rooms in `unused_rooms`. If so, the room with the lowest number is assigned to the current meeting. This follows the principle of allocating meetings to the unused room with the lowest number.

In the event that no rooms are available in `unused_rooms`, we resort to delaying the current meeting. We find the room with the earliest availability time (derived from the first item in `used_rooms`.) We then adjust the availability time of this room based on the duration of the delayed meeting, and push the room back into `used_rooms`. This ensures that meetings with earlier original start times are given priority when rooms become available and delayed meetings have the same duration as the original meeting.

Throughout this process, a crucial aspect is tracking of the count of meetings held in each room using the `meeting_count` array. This array is instrumental in determining the room that hosted the most meetings. After we have selected the room that hosts the meeting, we increment the count of meetings that occurred in that room.

Finally, we identify the room that held the most meetings and, in the case of a tie, select the room with the lowest number.

### **Algorithm**

1. Create two priority queues, `unused_rooms` and `used_rooms`, representing the available and currently used rooms, respectively. Create an array `meeting_count` of size `n` to keep track of the number of meetings held in each room.
2. Use the `heapify` function to convert `unused_rooms` into a min heap, ensuring the room with the lowest number is at the top.
3. Iterate through the meetings sorted by start times.
4. While there are used rooms (`used_rooms`) and the first room's meeting has already concluded (meeting end time <= current meeting start time), remove the room from `used_rooms` and add it back to `unused_rooms`.
5. Check if there are available rooms (`unused_rooms`). If available, pop the room with the lowest number from `unused_rooms` and allocate the meeting to that room. Update `used_rooms` with the meeting end time and the room number.
6. If no available rooms, pop the room with the earliest availability time from `used_rooms`. Adjust the availability time for the room to accommodate the delayed meeting. Update `used_rooms` with the adjusted availability time and room number.
7. Increment the meeting count for the allocated room.
8. After processing all meetings, return the index of the room with the maximum meeting count using. If there are multiple rooms with the same maximum meeting count, return the room with the lowest index.

### 🎯 LeetCode Official Solution

```java
class Solution {
    public int mostBooked(int n, int[][] meetings) {
        var meetingCount = new int[n];
        var usedRooms = new PriorityQueue<long[]>((a, b) -> a[0] != b[0] ? Long.compare(a[0], b[0]) : Long.compare(a[1], b[1]));
        var unusedRooms = new PriorityQueue<Integer>();

        for (int i = 0; i < n; i++) {
            unusedRooms.offer(i);
        }

        Arrays.sort(meetings, (a, b) -> a[0] != b[0] ? Integer.compare(a[0], b[0]) : Integer.compare(a[1], b[1]));

        for (int[] meeting : meetings) {
            int start = meeting[0], end = meeting[1];

            while (!usedRooms.isEmpty() && usedRooms.peek()[0] <= start) {
                int room = (int) usedRooms.poll()[1];
                unusedRooms.offer(room);
            }

            if (!unusedRooms.isEmpty()) {
                int room = unusedRooms.poll();
                usedRooms.offer(new long[]{end, room});
                meetingCount[room]++;
            } else {
                long roomAvailabilityTime = usedRooms.peek()[0];
                int room = (int) usedRooms.poll()[1];
                usedRooms.offer(new long[]{roomAvailabilityTime + end - start, room});
                meetingCount[room]++;
            }
        }

        int maxMeetingCount = 0, maxMeetingCountRoom = 0;
        for (int i = 0; i < n; i++) {
            if (meetingCount[i] > maxMeetingCount) {
                maxMeetingCount = meetingCount[i];
                maxMeetingCountRoom = i;
            }
        }

        return maxMeetingCountRoom;
    }
}
```

### ⏳ Complexity Analysis

Let *N* be the number of rooms.

Let *M* be the number of meetings.

- Time complexity: *O*(*M*⋅log*M*+*M*⋅log*N*+*N*⋅log*N*)
    
    Sorting `meetings` will incur a time complexity of *O*(*M*⋅log*M*).
    
    Popping and pushing into the priority queue will each cost *O*(log*N*). These priority queue operations run inside a for loop that runs at most *M* times, leading to a time complexity of *O*(*M*⋅log*N*).
    
    The inner nested loop will incur a time complexity of *O*(log*N*). Additionally, initializing the heap of unused rooms takes *O*(*N*⋅log*N*) time in languages like C++ and Java.
    
    The combined time complexity is *O*(*M*⋅log*M*+*M*⋅log*N*+*N*⋅log*N*). As per the constraints, *N* is small, so the term *O*(*M*⋅log*M*) will typically dominate.
    
- Space complexity: *O*(*N*+*sort*).
    
    Initializing `unused_rooms` and `meeting_count` will incur a space complexity of *O*(*N*). Some extra space is used when we sort an array of size *N* in place. The space complexity of the sorting algorithm depends on the programming language.
    
    - In Python, the `sort` method sorts a list using the Timsort algorithm which is a combination of Merge Sort and Insertion Sort and has a space complexity of *O*(*N*).
    - In C++, the sort() function is implemented as a hybrid of Quick Sort, Heap Sort, and Insertion Sort, with a worst-case space complexity of *O*(log*N*).
    - In Java, Arrays.sort() is implemented using a variant of the Quick Sort algorithm which has a space complexity of *O*(log*N*).

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class RoomInfo {

    long meetingEndtime;
    int roomNumber;

    public RoomInfo(long meetingEndtime, int roomNumber) {
        this.meetingEndtime = meetingEndtime;
        this.roomNumber = roomNumber;
    }
}

class Solution {
    public int mostBooked(int n, int[][] meetings) {

        int[] freqMap = new int[n];
        Arrays.sort(meetings, (a, b) -> Integer.compare(a[0], b[0]));

        PriorityQueue<Integer> availableRooms = new PriorityQueue<>();
        PriorityQueue<RoomInfo> usedRooms = new PriorityQueue<>(
            (a, b) -> a.meetingEndtime != b.meetingEndtime 
            ? Long.compare(a.meetingEndtime, b.meetingEndtime)
            : Integer.compare(a.roomNumber, b.roomNumber));

        for (int i = 0; i < n; i++) {
            availableRooms.offer(i);
        }
        for (int i = 0; i < meetings.length; i++) {
            long currentStart = meetings[i][0];
            long currentEnd = meetings[i][1];

            // freeing up used rooms is important
            while (!usedRooms.isEmpty() && currentStart >= usedRooms.peek().meetingEndtime) {
                RoomInfo roomToBeMadeAvailable = usedRooms.poll();
                availableRooms.offer(roomToBeMadeAvailable.roomNumber);
            }

            if (!availableRooms.isEmpty()) {
                int roomNo = availableRooms.poll();
                usedRooms.offer(new RoomInfo(currentEnd, roomNo));
                freqMap[roomNo]++;
            } else {
                // check for earliest available room
                RoomInfo nextAvailableRoom = usedRooms.poll();
                int nextAvailableRoomNo = nextAvailableRoom.roomNumber;
                long nextMeetingEndtime = nextAvailableRoom.meetingEndtime;
                RoomInfo currentMeeting = new RoomInfo(nextMeetingEndtime + currentEnd - currentStart, nextAvailableRoomNo);
                usedRooms.offer(currentMeeting);
                freqMap[nextAvailableRoomNo]++;
            }
        }
        int maxMeetings = 0;
        int roomNumberResult = -1;
        for (int i = 0; i < freqMap.length; i++) {
            if (freqMap[i] > maxMeetings) {
                maxMeetings = freqMap[i];
                roomNumberResult = i;
            }
        }
        return roomNumberResult;
    }
}
```