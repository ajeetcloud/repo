# 424. Longest Repeating Character Replacement

LeetCode URL: https://leetcode.com/problems/longest-repeating-character-replacement
Approach: Use: (windowLength - maxFreq ≤ k), if yes, increase the window size(end++), if no, move start forward(start++)
Coding Pattern: Sliding Window
Company: Amazon, Google, Meta
Date Solved: March 6, 2025
Difficulty Level: Medium
Frequency of Revision: Weekly
Problem Progress: Completed
Time Complexity: O(n)
Space Complexity: O(n)
Topic: Sliding Window

### 🐞 Problem Statement

You are given a string `s` and an integer `k`. You can choose any character of the string and change it to any other uppercase English character. You can perform this operation at most `k` times.

Return *the length of the longest substring containing the same letter you can get after performing the above operations*.

**Example 1:**

```
Input: s = "ABAB", k = 2
Output: 4
Explanation: Replace the two 'A's with two 'B's or vice versa.
```

**Example 2:**

```
Input: s = "AABABBA", k = 1
Output: 4
Explanation: Replace the one 'A' in the middle with 'B' and form "AABBBBA".
The substring "BBBB" has the longest repeating letters, which is 4.
There may exists other ways to achieve this answer too.
```

---

### 🧮 Approach / Algorithm Design

## **Solution**

---

### **Overview**

In this problem, we are given a string `s` consisting of uppercase English alphabets. We are allowed to replace any letter of this string with any other uppercase English letter in one operation. A maximum of *k* such operations are permitted.

We need to find the longest substring after at most *k* operations such that all the letters are identical and return its length.

There are several ways to solve this problem. We start with the brute force solution and improve it with a binary-search-based approach. We build on the understanding developed from the previous methods and present an optimized *O*(*n*) solution which uses an expanding sliding window.

---

### **Approach 1: Sliding Window + Binary Search**

### **Intuition**

Since the question asks us to find the longest substring length that satisfies the given conditions, we can start with generating all possible substrings.

Now, given a substring, we want to find out if it can be converted into a string with the same letters. Because we are allowed only *k* operations to do so, we would want to minimize the number of operations.

We can divide all the characters of the string `s` into two groups - fixed letters and the letters that will be changed. Fixed letters remain unchanged. The rest of the letters would be substituted by fixed letters. To keep the number of substitutions minimum, the number of fixed letters must be maximum.

So, we find the character *target*, which occurs with the maximum frequency in the string. All other characters can now be replaced with *target*. If the count of other characters is less than or equal to *k*, then this substring fulfills the condition given in the question. We'd call it a valid substring.

![image.png](image.png)

We can try it over every substring and filter out all the valid substrings. The length of the longest valid substring would be our answer. However, this is a time-consuming process, for it involves nested for loops which take O(n 2) time only for generating substring ranges and the additional overhead of calculating the maximum frequency element.

### **Optimization**

While this might not be a good solution, we learn an important idea here. We observe that if a valid substring of length *i* exists, then we can indeed say that a valid substring of length *i*−1 would also exist.

Let's understand this with an example.

`s = "ABCCDC", k = 1`

Let's revisit the condition of validity - a substring is valid if, after at most *k* character replacements, all the letters in the substring become the same.

In this case, `CCDC` is the longest substring that satisfies the given condition. We can take any substring of `CCDC`, and it would still be valid. That's because any substring of a valid string can never contain more than *k* instances of *other characters* (any character other than `C` in this example). According to the condition of validity, it would make a valid substring.

Using induction, we can say that if there exists a valid string of length *i*, then all of its substrings of lengths *i*−1, *i*−2, *i*−3... 2 and 1 would also be valid.

We can observe that it is making a monotonic function over the length of a valid substring. For the example given above, we have -

| **substring length** | **1** | **2** | **3** | **4** | **5** | **6** |
| --- | --- | --- | --- | --- | --- | --- |
| valid | true | true | true | true | false | false |

We want to find the longest valid substring. Because of the presence of monotonic values, we should be able to use binary search over the length of substrings. We try to find out if a valid substring with a certain length exists or not.

How to check whether a valid substring of a given length exists or not?

A valid substring of a given length could exist anywhere in the string. Think of a window of the given size which slides over the string from left to right. If a valid substring of the given length does exist, one of the sliding window positions will provide it to us.

As discussed earlier, we would need the element that appears the maximum number of times. A frequency map can be helpful here. A frequency map stores a list of characters with the frequency they appear in a particular window. Starting from the left edge of the string, we build a frequency map of the window. As we move the window of fixed length toward the right, the frequency of the new character added to the window increases, and the frequency of the departing character decreases.

Using this frequency map, we can easily check when we come across a valid window.

As we move the sliding window from left to right, we also keep track of the maximum frequency we have seen so far of any character in the sliding window. When we subtract the frequency from the size of the window, we get the count of all other characters which would be replaced. For a valid substring, the number of other characters should be less than or equal to *k*.

![](https://leetcode.com/problems/longest-repeating-character-replacement/Figures/424/424-substrings-of-valid-substring.png)

### **Approach 2: Sliding Window (Fast)**

### **Intuition**

Let's revisit the first approach, where we apply binary search to different lengths of substrings. Depending on whether a substring meets the specified conditions or not, we increase or decrease the length of the substring. We use a sliding window-based approach to test the validity condition.

Note that the size of the sliding window does not change while it moves across the string. We test to see if the window ever becomes valid. If it does, we *try again from the beginning*, increasing the window size (or decreasing it if it remains invalid). In this way, we try to find the longest valid window. But do we need to start at the beginning of the string again?

Recall that when a string of length *l* is valid, all its substrings form a valid string. Let's try looking at it from the other side. Suppose we have identified a valid substring/window of length *l*−1. To find an even longer valid window, we should try adding the next alphabet. This temporarily increases the size of the window to *l*. We check whether it forms a valid window or not. If not, we move the beginning of the window to the right, which resets the window size back to *l*−1 and effectively moves the window to the right.

We keep moving it until we reach a point where we find a valid window of size *l*. Now, we don't need to stop there. We can continue looking for a valid window of size *l*+1. We continue this process until the window hits the right edge of the string. The size of the window at the end would be our answer.

The key takeaway here is that once we have found a valid window, we don't need to decrease the size of it. The window keeps moving toward the right. At each step, even if the window becomes invalid, we never decrease its size. We increase the size only when we find a valid window of larger size.

**Now let's look at it a bit more formally**

We begin with a sliding window of size 0 positioned at the left edge of the string. We consider an empty window as valid.

*start* points at the first character of the window initially positioned at index 0. *end* points at the last character of the window initially positioned at index −1. We can see that the window's size is 0 (*end*+1−*start*=−1+1−0=0). Here, we also consult our old friend, the frequency map. It stores a map of characters to their frequencies in the window; we call it *frequencyMap*.

Our objective is to find the longest valid window. So, whenever we see a valid window, we try to expand its size by moving the *end* pointer forward. As we move the pointer forward, we update the *frequencyMap* as well. The frequency map helps us keep track of the character that appears most frequently in the window. We compare the frequency of the newly added character with the maximum frequency of any character seen so far - *maxFrequency*. We update *maxFrequency* when we find a new maximum.

The window size increases only when *maxFrequency* finds a new maximum. For this, we always want the following condition to hold true -

*windowSize*−*maxFrequency*<=*k*

We stop moving the *end* pointer forward, or in other words, stop expanding the window when it becomes invalid. Say the size of the window when it becomes invalid is *l*. We know the previous window with the size *l*−1 was valid. So, we move the prior window of length *l*−1 toward the right. To do so, the *start* pointer moves one step further. Remember that the *end* pointer had already moved, so we don't need to move the *end* pointer again.

At this point, the last valid window has moved one step to the right, but it might still be invalid. As explained earlier, we are only interested in larger windows, so we don't need to decrease the window size. We move the window of size *i*−1 further and further to the right until it becomes valid again.

If we come across a valid window, we try to expand it as much as possible, and the process continues until the *end* pointer reaches the rightmost alphabet of the string. At this point, the size of the window indicates the longest valid substring seen yet.

### 🎯 LeetCode Official Solution

```java
class Solution {
    public int characterReplacement(String s, int k) {
        int start = 0;
        int[] frequencyMap = new int[26];
        int maxFrequency = 0;
        int longestSubstringLength = 0;

        for (int end = 0; end < s.length(); end += 1) {
            // if 'A' is 0, then what is the relative order
            // or offset of the current character entering the window
            // 0 is 'A', 1 is 'B' and so on
            int currentChar = s.charAt(end) - 'A';

            frequencyMap[currentChar] += 1;

            // the maximum frequency we have seen in any window yet
            maxFrequency = Math.max(maxFrequency, frequencyMap[currentChar]);

            // move the start pointer towards right if the current
            // window is invalid
            Boolean isValid = (end + 1 - start - maxFrequency <= k);
            if (!isValid) {
                // offset of the character moving out of the window
                int outgoingChar = s.charAt(start) - 'A';

                // decrease its frequency
                frequencyMap[outgoingChar] -= 1;

                // move the start pointer forward
                start += 1;
            }

            // the window is valid at this point, note down the length
            // size of the window never decreases
            longestSubstringLength = end + 1 - start;
        }

        return longestSubstringLength;
    }
}
```

### ⏳ Complexity Analysis

If there are *n* characters in the given string -

- Time complexity: *O*(*n*). In this approach, we access each index of the string at most two times. When it is added to the sliding window, and when it is removed from the sliding window. The sliding window always moves forward. In each step, we update the frequency map, *maxFrequency*, and check for validity, they are all constant-time operations. To sum up, the time complexity is proportional to the number of characters in the string - *O*(*n*).
- Space complexity: *O*(*m*). Similar to the previous approaches, this approach requires an auxiliary frequency map. The maximum number of keys in the map equals the number of unique characters in the string. If there are *m* unique characters, then the memory required is proportional to *m*. So the space complexity is *O*(*m*). Considering uppercase English letters only, *m*=26.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
  public int characterReplacement(String s, int k) {
    int start = 0;
    int end = 0;
    int lastIndex = s.length() - 1;
    int[] freqMap = new int[26];
    int result = 0;
    int maxFreq = 0;
    int windowLength = 0;
    while (end <= lastIndex) {
      int currentChar = s.charAt(end) - 'A';
      freqMap[currentChar]++;
      maxFreq = Math.max(maxFreq, freqMap[currentChar]);
      windowLength = end - start + 1;
      if (windowLength - maxFreq <= k) {
        result = Math.max(result, windowLength);
      } else {
        int leavingChar = s.charAt(start) - 'A';
        freqMap[leavingChar]--;
        start++;
      }
      end++;
    }
    return result;
  }
}
```

### 🧩 Educative Approach

### **Optimized approach using sliding window**

The solution to this problem can be optimized using the sliding window pattern. For this purpose, we use two pointers to slide our window over the input string. We initialize the `start` and the `end` pointer with 00. To move the window over the input string, we change the positions of the pointers as follows:

- Increment the `end` pointer until the window becomes invalid.
- Increment the `start` pointer only if the window is invalid to make it valid again.

We keep track of the frequency of characters in the current window using a hash map. We also maintain a variable, `lengthOfMaxSubstring`, to keep track of the longest substring with the same characters after replacements and `mostFreqChar` to keep track of the frequency of the most occurring character.

We check whether the new character is in the hash map in each iteration. If it is present in the hash map, we increment its frequency by 11; otherwise, we add the character in the hash map and set its frequency to 11. Next, we compare the frequency of the new character with `mostFreqChar` to update the frequency of the most occurring character so far using the following expression:

max(most freq char, frequency of new character)*max*(*most* *freq* *char*, *frequency* *of* *new* *character*)

Then, we use the following expression to check if the number of characters in the window other than the most occurring character is greater than `k`:

*end* − *start* + 1 − *most* *freq* *char* > *k*

If the expression above returns TRUE, the number of replacements required in the current window has exceeded our limit, that is, `k`. In this case, we decrement the frequency of the character to be dropped out of the window and adjust the window by moving the `start` pointer by 11 to make the window valid again. We continue this process until we have traversed the entire string.

Then, we update `lengthOfMaxSubstring` with the current window size if the window size is greater than `lengthOfMaxSubstring`.

Finally, when the entire input string has been traversed, we return the length of the longest substring such that all the characters in the substring are the same.

### **Solution summary**

To recap, the solution can be divided into the following parts:

1. We iterate over the input string using two pointers.
2. In each iteration:
    1. If the new character is not present in the hash map, we add it. Otherwise, we increment its frequency by 1.
    2. We slide the window one step forward if the number of replacements required in the current window has exceeded our limit.
    3. If the current window is the longest so far, then we update the length of the longest substring that has the same character.
3. Finally, we return the length of the longest substring with the same character after replacements.

```java
import java.util.*;

public class RepeatingCharacter {
    public static int longestRepeatingCharacterReplacement(String s, int k) {
        int stringLength = s.length();
        int lengthOfMaxSubstring = 0;
        int start = 0;
        Map<Character, Integer> charFreq = new HashMap<>();
        int mostFreqChar = 0;

        for (int end = 0; end < stringLength; ++end) {
            char currentChar = s.charAt(end);
            
            charFreq.put(currentChar, charFreq.getOrDefault(currentChar, 0) + 1);
            
            mostFreqChar = Math.max(mostFreqChar, charFreq.get(currentChar));

            if (end - start + 1 - mostFreqChar > k) {
                charFreq.put(s.charAt(start), charFreq.get(s.charAt(start)) - 1);
                start += 1;
            }

            lengthOfMaxSubstring = Math.max(lengthOfMaxSubstring, end - start + 1);
        }

        return lengthOfMaxSubstring;
    }
}
```