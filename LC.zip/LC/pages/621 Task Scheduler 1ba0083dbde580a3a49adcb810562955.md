# 621. Task Scheduler

LeetCode URL: https://leetcode.com/problems/task-scheduler
Approach: Create a freqMap. Sort the freqMap. gaps is maxFreq - 1. idleSlots is gaps*n; Adjust idleSlots = idleSlots - Math.min(gaps, freq[i]). Final result is tasks.length + idleSlots.
Coding Pattern: Merge Intervals
Company: Amazon, Apple, Google
Date Solved: March 14, 2025
Difficulty Level: Medium
Frequency of Revision: Weekly
Problem Progress: Completed
Time Complexity: O(n)
Space Complexity: O(1)
Topic: Arrays

### 🐞 Problem Statement

You are given an array of CPU `tasks`, each labeled with a letter from A to Z, and a number `n`. Each CPU interval can be idle or allow the completion of one task. Tasks can be completed in any order, but there's a constraint: there has to be a gap of **at least** `n` intervals between two tasks with the same label.

Return the **minimum** number of CPU intervals required to complete all tasks.

**Example 1:**

**Input:** tasks = ["A","A","A","B","B","B"], n = 2

**Output:** 8

**Explanation:** A possible sequence is: A -> B -> idle -> A -> B -> idle -> A -> B.

After completing task A, you must wait two intervals before doing A again. The same applies to task B. In the 3rd interval, neither A nor B can be done, so you idle. By the 4th interval, you can do A again as 2 intervals have passed.

**Example 2:**

**Input:** tasks = ["A","C","A","B","D","B"], n = 1

**Output:** 6

**Explanation:** A possible sequence is: A -> B -> C -> D -> A -> B.

With a cooling interval of 1, you can repeat a task after just one other task.

**Example 3:**

**Input:** tasks = ["A","A","A", "B","B","B"], n = 3

**Output:** 10

**Explanation:** A possible sequence is: A -> B -> idle -> idle -> A -> B -> idle -> idle -> A -> B.

There are only two types of tasks, A and B, which need to be separated by 3 intervals. This leads to idling twice between repetitions of these tasks.

---

### 🧮 Approach / Algorithm Design

### **Overview**

We are given characters, which are tasks to be scheduled in the CPU. The objective is to find the minimum time required to complete all tasks while including a cooldown period between two identical tasks. The cooldown period is represented by a non-negative integer `n`. During each unit of time, the CPU can either complete a task or stay idle. The goal is to optimize the schedule to minimize the total time required to process all the tasks.

**Key Observations:**

1. Tasks represented by the same character are considered identical.
2. Repeated tasks should be at least `n` intervals apart from each other because of the cooling time.
3. You can put the idle time effectively in between two repetative tasks to schedule them.

Checkout the below visual of example 1 from the problem description:

![](https://leetcode.com/problems/task-scheduler/Figures/621_fix/overiew.png)

The result is 8 intervals, which is calculated by tasks + idle time (6 + 2). The problem involves finding how much idle time is required to complete the tasks.

All approaches use a greedy strategy, meaning decisions are made step by step, focusing on what seems best in the moment to reach the overall best solution. To show that this type of approach works well, let's use some illustrations. We can prove its effectiveness by showing what happens if we assume the opposite and reach a contradiction.

Using proof by contradiction, we can demonstrate that selecting the task with the lowest frequency increases idle time for the scheduler, thereby failing to maximize efficiency. Conversely, choosing tasks with higher frequencies maximizes efficiency.

![](https://leetcode.com/problems/task-scheduler/Figures/621_fix/contradiction.png)

The Greedy approach optimizes efficiency by prioritizing tasks based on their frequency, thereby reducing intervals and minimizing idle time for the scheduler. This strategy ultimately leads to the maximization of overall efficiency.

![](https://leetcode.com/problems/task-scheduler/Figures/621_fix/greedy_works.png)

> After finishing this problem, take a shot at Task Scheduler II for a deeper understanding of recognizing patterns.
> 

### **Approach: Filling the Slots and Sorting**

### **Intuition**

We need to find the minimum time required to complete all tasks given the constraint that at least `n` units of time must elapse between two identical tasks. To minimize the time, we should first consider scheduling the most frequent tasks so that they are separated by `n` units of time. Then, we can fill the idle slots with the remaining tasks.

### **Example:**

Consider the task list `['A', 'A', 'A', 'B', 'B', 'B']` with `n = 2`.

1. Calculate the frequency array: `[3, 3, 0, ..., 0]`, as 'A' appears 3 times and 'B' appears 3 times.
2. Sort the frequency array in ascending order: `[0, 0, ..., 3, 3]`.
3. Calculate `maxFreq` as `freq[25] - 1`. In this case, `maxFreq = 3 - 1 = 2`.
4. Calculate the number of idle slots: `idleSlots = maxFreq * n = 2 * 2 = 4`.
5. The loop starts from the second highest frequency (index 24 in the sorted array) and goes down to the lowest frequency. This ensures that the highest frequency task's idle slots are considered only once, as it was accounted for when calculating `maxFreq` in the earlier step.
6. In each iteration, subtract the minimum of `maxFreq` and the current frequency from `idleSlots`. For the first iteration, subtract `min(2, 2) = 2` from `idleSlots`, resulting in `idleSlots = 4 - 2 = 2`.
7. If `idleSlots > 0`, add the remaining idle slots to the total number of tasks. In this example, there are 2 idle slots, so the final result is obtained by adding these idle slots (2) to the total number of tasks (6).
8. Thus, the minimum time required to complete all tasks, considering the cooldown period, is `8`.

### **Algorithm**

- Create a `freq` array of size 26 to keep track of the count of each task.
- Iterate through the `tasks` array and update the frequency array with the frequency of each task.
- Sort the frequency array in non-decreasing order (ascending order = smallest to largest). This is done to process tasks with higher frequencies first.
- Calculate the maximum frequency of the most frequent task. Subtract 1 because we want to find the number of intervals, not the number of occurrences.
- Calculate the number of `idleSlots` that will be required by multiplying the maximum frequency by the cooldown period.
- Iterate over the frequency array from the second highest frequency to the lowest frequency.
    - Subtract the minimum of the maximum frequency and the current frequency from the `idleSlots`.
- If there are any `idleSlots` left, add them to the total number of tasks and return this as the answer. Otherwise, return the total number of tasks.

### 🎯 LeetCode Official Solution

```java
class Solution {
    public int leastInterval(char[] tasks, int n) {
        // Create a frequency array to keep track of the count of each task
        int[] freq = new int[26];
        for (char task : tasks) {
            freq[task - 'A']++;
        }

        // Sort the frequency array in non-decreasing order
        Arrays.sort(freq);
        // Calculate the maximum frequency of any task
        int maxFreq = freq[25] - 1;
        // Calculate the number of idle slots that will be required
        int idleSlots = maxFreq * n;

        // Iterate over the frequency array from the second highest frequency to the lowest frequency
        for (int i = 24; i >= 0 && freq[i] > 0; i--) {
            // Subtract the minimum of the maximum frequency and the current frequency from the idle slots
            idleSlots -= Math.min(maxFreq, freq[i]);
        }

        // If there are any idle slots left, add them to the total number of tasks
        return idleSlots > 0 ? idleSlots + tasks.length : tasks.length;
    }
}
```

### ⏳ Complexity Analysis

Let the number of tasks be *N*. There are up to 26 distinct tasks because the tasks are represented by the letters A to Z.

- Time complexity: *O*(*N*)
    
    The time complexity of the algorithm is *O*(26log26+*N*), where 26log26 is the time complexity of sorting the frequency array, and *N* is the length of the input task list, which is the dominating term.
    
- Space complexity: *O*(26)=*O*(1)
    
    The frequency array has a size of 26.
    
    Note that some extra space is used when we sort arrays in place. The space complexity of the sorting algorithm depends on the programming language.
    
    - In Python, the sort method sorts a list using the Timsort algorithm which is a combination of Merge Sort and Insertion Sort and has *O*(*N*) additional space.
    - In Java, `Arrays.sort()` is implemented using a variant of the Quick Sort algorithm which has a space complexity of *O*(log*N*) for sorting array.
    - In C++, the `sort()` function is implemented as a hybrid of Quick Sort, Heap Sort, and Insertion Sort, with a worse-case space complexity of *O*(log*N*).
    
    We sort the frequency array, which has a size of 26. The space used for sorting takes *O*(26) or *O*(log26), which is constant, so the space complexity of the algorithm is *O*(26), which is constant, i.e. *O*(1).
    

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
  public int leastInterval(char[] tasks, int n) {
    int freq[] = new int[26];
    for (int i = 0; i < tasks.length; i++) {
      freq[tasks[i] - 'A']++;
    }
    Arrays.sort(freq);
    int gaps = freq[25] - 1;
    int idleSlots = gaps * n;
    for (int i = 24; i >= 0 && freq[i] > 0; i--) {
      idleSlots = idleSlots - Math.min(gaps, freq[i]);
      if (idleSlots < 0) {
        idleSlots = 0;
        break;
      }
    }
    return tasks.length + idleSlots;
  }
}
```