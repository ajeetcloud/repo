# 24. Swap Nodes in Pairs

LeetCode URL: https://leetcode.com/problems/swap-nodes-in-pairs
Approach: Trick: Add a dummy node before head to ease corner case handling. Keep track of prev node, and add its next node according to the pair.
Coding Pattern: Linked List Manipulation In-Place
Company: Amazon, Google
Date Solved: May 5, 2025
Difficulty Level: Medium
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n)
Space Complexity: O(1)
Topic: Linked List

### 🐞 Problem Statement

Given a linked list, swap every two adjacent nodes and return its head. You must solve the problem without modifying the values in the list's nodes (i.e., only nodes themselves may be changed.)

**Example 1:**

**Input:** head = [1,2,3,4]

**Output:** [2,1,4,3]

**Explanation:**

![](https://assets.leetcode.com/uploads/2020/10/03/swap_ex1.jpg)

**Example 2:**

**Input:** head = []

**Output:** []

**Example 3:**

**Input:** head = [1]

**Output:** [1]

**Example 4:**

**Input:** head = [1,2,3]

**Output:** [2,1,3]

---

### 🧮 Approach / Algorithm Design

**Approach 2: Iterative Approach**

**Intuition**

The concept here is similar to the recursive approach. We break the linked list into pairs by jumping in steps of two. The only difference is, unlike recursion, we swap the nodes on the go. After swapping a pair of nodes, say `A` and `B`, we need to link the node `B` to the node that was right before `A`. To establish this linkage we save the previous node of node `A` in `prevNode`.

![](https://leetcode.com/problems/swap-nodes-in-pairs/Figures/24/24_Swap_Nodes_5.png)

**Algorithm**

1. We iterate the linked list with jumps in steps of two.
2. Swap the pair of nodes as we go, before we jump to the next pair. Let's represent the two nodes to be swapped by `firstNode` and `secondNode`.
    
    ![](https://leetcode.com/problems/swap-nodes-in-pairs/Figures/24/24_Swap_Nodes_6.png)
    
3. Swap the two nodes. The swap step is
    
    ```
       firstNode.next = secondNode.next
       secondNode.next = firstNode
    
    ```
    
    ![](https://leetcode.com/problems/swap-nodes-in-pairs/Figures/24/24_Swap_Nodes_7.png)
    
4. We also need to assign the `prevNode`'s next to the head of the swapped pair. This step would ensure the currently *swapped* pair is linked correctly to the end of the previously *swapped* list.
    
    ```
       prevNode.next = secondNode
    
    ```
    
    ![](https://leetcode.com/problems/swap-nodes-in-pairs/Figures/24/24_Swap_Nodes_8.png)
    
    This is an iterative step, so the nodes are swapped on the go and attached to the previously swapped list. And in the end we get the final swapped list.
    

### 🎯 LeetCode Official Solution

```java
/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
class Solution {
    public ListNode swapPairs(ListNode head) {
        // Dummy node acts as the prevNode for the head node
        // of the list and hence stores pointer to the head node.
        ListNode dummy = new ListNode(-1);
        dummy.next = head;

        ListNode prevNode = dummy;

        while ((head != null) && (head.next != null)) {
            // Nodes to be swapped
            ListNode firstNode = head;
            ListNode secondNode = head.next;

            // Swapping
            prevNode.next = secondNode;
            firstNode.next = secondNode.next;
            secondNode.next = firstNode;

            // Reinitializing the head and prevNode for next swap
            prevNode = firstNode;
            head = firstNode.next; // jump
        }

        // Return the new head node.
        return dummy.next;
    }
}
```

### ⏳ Complexity Analysis

- Time Complexity : *O*(*N*) where N is the size of the linked list.
- Space Complexity : *O*(1).

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
  public ListNode swapPairs(ListNode head) {

    if (head == null || head.next == null) {
      return head;
    }
    // dummy node helps us in handling corner cases with ease.
    ListNode dummy = new ListNode();
    dummy.next = head;
    ListNode c1 = head;
    ListNode c2 = c1.next;
    ListNode c3 = c2.next;
    ListNode newHead = c2;
    ListNode prevC1 = dummy;
    while (c2 != null) {
      c3 = c2.next;
      c2.next = c1;
      c1.next = c3;

      prevC1.next = c2;
      if (c3 == null) {
        break;
      }
      c2 = c3.next;
      prevC1 = c1;
      c1 = c3;
    }
    return dummy.next;
  }
}
```