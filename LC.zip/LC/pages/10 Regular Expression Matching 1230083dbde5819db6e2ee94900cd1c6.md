# 10. Regular Expression Matching

LeetCode URL: https://leetcode.com/problems/regular-expression-matching/description/?envType=problem-list-v2&envId=string
Date Solved: September 1, 2024
Difficulty Level: Hard
Frequency of Revision: Daily
Problem Progress: Need Review
Time Complexity: O(n^2)
Space Complexity: O(n!)
Topic: Dynamic Programming, Recursion, String

### 🐞 Problem Statement

Given an input string `s` and a pattern `p`, implement regular expression matching with support for `'.'` and `'*'` where:

- `'.'` Matches any single character.​​​​
- `'*'` Matches zero or more of the preceding element.

The matching should cover the **entire** input string (not partial).

---

### 🧮 Approach / Algorithm Design

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```cpp
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input: s = "aa", p = "a"
Output: false
Explanation: "a" does not match the entire string "aa".

```

**Example 2:**

```
Input: s = "aa", p = "a*"
Output: true
Explanation: '*' means zero or more of the preceding element, 'a'. Therefore, by repeating 'a' once, it becomes "aa".

```

**Example 3:**

```
Input: s = "ab", p = ".*"
Output: true
Explanation: ".*" means "zero or more (*) of any character (.)".
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```cpp
// LeetCode accepted Code goes here
class Solution(object):
    def isMatch(self, s, p):
        """
        :type s: str
        :type p: str
        :rtype: bool
        """
        
```