# Kth Smallest Number in M Sorted Lists

Approach: For each list, store its 0th number in the Heap along with list index. Takeout one from Heap, and add its next. Once k becomes zero, return takeout’s num.
Coding Pattern: K-way Merge
Company: Google
Date Solved: January 20, 2026
Difficulty Level: Medium
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O((m+k) log m)
Space Complexity: O(n)
Topic: Heap (Priority Queue)

### 🐞 Problem Statement

Given a list, `lists`, containing m*m* sorted lists of integers in ascending order, and an integer `k`, find the kth*kth* smallest element among all the lists.

Even if some values appear multiple times across the lists, each occurrence is treated as a unique element when determining the kth*kth* smallest number.

If `k` exceeds the total number of elements across all lists, return the largest element among them. If the lists are empty, return `0`.

**Constraints**:

- 1≤m≤501≤*m*≤50
- 0≤0≤ `lists[i].length` ≤50
- −109≤−109≤ `lists[i][j]` ≤109
- 1≤1≤ `k` ≤109

![image.png](image%203.png)

---

### 🧮 Approach / Algorithm Design

This algorithm works because the min heap keeps track of the smallest available numbers from all lists. Since each list is already sorted, we only need to store one number from each list simultaneously. When we remove the smallest number from the heap, we replace it with the next number from the same list. This way, we ensure numbers are processed in the same sequence they appear if we had fully merged the lists. This guarantees that when we extract the kth number, it is exactly the kth smallest across all lists.

Now, let’s look at the solution steps below:

1. Determine the number of input lists and store it in `listLength`.
2. Initialize a min heap (`kthSmallest`) to keep track of the smallest available elements from the lists.
3. Push the first element of each non-empty list into `kthSmallest`, storing:
    1. The element value
    2. The index of the list it belongs to (`listIndex`)
    3. The position of the element within its list (`numIndex`)
4. Initialize the counters: set `numbersChecked` to track the number of extracted elements and `smallestNumber` to store the latest smallest number, starting at zero.
5. Repeatedly extract the smallest element from `kthSmallest` until `k` elements have been removed, incrementing `numbersChecked` with each extraction.
6. Break the iterations if `numbersChecked` equals `k`.
7. Otherwise, push the next element from the same list into `kthSmallest` (if available) to maintain the heap.
8. In the end, return the kth*kth* smallest number, which is stored in `smallestNumber`, as the final result.

> **Note**: We’ll implement the heap using the `PriorityQueue` class.
> 

The slides below illustrate how we would like the algorithm to run.

### **Solution summary**

We can summarize our solution in the following steps.

1. Push the first element of each list in the min-heap.
2. Pop the top element of the min-heap, and keep track of the list index and the element index in the list. Now, push the next element of the popped element from the list if the element index is not the last index in the list.
3. Repeat step 2 until we have popped *k* elements from the heap. If we have popped *k* elements, then the *kth* element popped in this process is the *kth* smallest element.

### 🎯 LeetCode Official Solution

```java
    public static int kSmallestNumber(List<List<Integer>> lists, int k) {
        int listLength = lists.size();
        PriorityQueue<int[]> kthSmallest = new PriorityQueue<>((a, b) -> a[0] - b[0]);

        for (int index = 0; index < listLength; index++) {
            if (lists.get(index).size() == 0) {
                continue;
            } else {
                kthSmallest.offer(new int[] {lists.get(index).get(0), index, 0});
            }
        }

        int numbersChecked = 0, smallestNumber = 0;
        while (!kthSmallest.isEmpty()) {  
            int[] smallest = kthSmallest.poll();
            smallestNumber = smallest[0];
            int listIndex = smallest[1];
            int numIndex = smallest[2];
            numbersChecked++;

            if (numbersChecked == k) {
                break;
            }

            if (numIndex + 1 < lists.get(smallest[1]).size()) {
                kthSmallest.offer(new int[] {lists.get(listIndex).get(numIndex + 1), listIndex, numIndex + 1});
            }
        }
        return smallestNumber;
    }
```

### ⏳ Complexity Analysis

### **Time complexity**

The time complexity of the first step is

- O(m) for iterating the first element of each list, where m*m* is the number of lists.
- The cost of pushing m*m* elements in the heap is as follows:

log⁡1+log⁡2+log⁡3+⋯+log⁡m=log⁡(1∗2∗3∗⋯∗m)=log⁡(m!)log1+log2+log3+⋯+log*m*=log(1∗2∗3∗⋯∗*m*)=log(*m*!)

As per Stirling’s approximation, O(logm!)≈O(mlogm).

So, the time complexity of the first loop is O(mlog⁡m).

- In the `while` loop, we pop and push on to the heap *k* number of times until we find the *kth* smallest number. So, the time complexity of this step is *O*(*k*log*m*).

So, the total time complexity of this solution is

O(mlogm+klogm)=**O((m+k)logm)**

### **Space complexity**

The space complexity is *O*(*m*), where m*m* is the total number of elements in the heap.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
    public static int kSmallestNumber(List<List<Integer>> lists, int k) {
        int listLength = lists.size();
        PriorityQueue<int[]> kthSmallest = new PriorityQueue<>((a, b) -> a[0] - b[0]);

        for (int index = 0; index < listLength; index++) {
            if (lists.get(index).size() == 0) {
                continue;
            } else {
                kthSmallest.offer(new int[] {lists.get(index).get(0), index, 0});
            }
        }

        int numbersChecked = 0, smallestNumber = 0;
        while (!kthSmallest.isEmpty()) {  
            int[] smallest = kthSmallest.poll();
            smallestNumber = smallest[0];
            int listIndex = smallest[1];
            int numIndex = smallest[2];
            numbersChecked++;

            if (numbersChecked == k) {
                break;
            }

            if (numIndex + 1 < lists.get(smallest[1]).size()) {
                kthSmallest.offer(new int[] {lists.get(listIndex).get(numIndex + 1), listIndex, numIndex + 1});
            }
        }
        return smallestNumber;
    }
```