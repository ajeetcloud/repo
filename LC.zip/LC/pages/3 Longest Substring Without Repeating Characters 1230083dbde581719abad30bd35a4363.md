# 3. Longest Substring Without Repeating Characters

LeetCode URL: https://leetcode.com/problems/longest-substring-without-repeating-characters/description/?envType=problem-list-v2&envId=string
Date Solved: September 1, 2024
Difficulty Level: Medium
Frequency of Revision: Weekly
Problem Progress: To Do
Time Complexity: O(n)
Space Complexity: O(2^n)
Topic: String

### 🐞 Problem Statement

Given a string `s`, find the length of the **longest substring** without repeating characters.

---

### 🧮 Approach / Algorithm Design

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```cpp
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input: s = "abcabcbb"
Output: 3
Explanation: The answer is "abc", with the length of 3.

```

**Example 2:**

```
Input: s = "bbbbb"
Output: 1
Explanation: The answer is "b", with the length of 1.

```

**Example 3:**

```
Input: s = "pwwkew"
Output: 3
Explanation: The answer is "wke", with the length of 3.
Notice that the answer must be a substring, "pwke" is a subsequence and not a substring.
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```jsx
// LeetCode accepted Code goes here
/**
 * @param {string} s
 * @return {number}
 */
var lengthOfLongestSubstring = function(s) {
    
};
```