# 143. Reorder List

LeetCode URL: https://leetcode.com/problems/reorder-list
Approach: Find middle node. Reverse second half of the list. Merge both halves alternatively.
Coding Pattern: Linked List Manipulation In-Place
Company: Amazon, Google, Meta
Date Solved: May 1, 2025
Difficulty Level: Medium
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n)
Space Complexity: O(1)
Topic: Linked List, Two Pointers

### 🐞 Problem Statement

You are given the head of a singly linked-list. The list can be represented as:

```
L0 → L1 → … → Ln - 1 → Ln
```

*Reorder the list to be on the following form:*

```
L0 → Ln → L1 → Ln - 1 → L2 → Ln - 2 → …
```

You may not modify the values in the list's nodes. Only nodes themselves may be changed.

**Example 1:**

![](https://assets.leetcode.com/uploads/2021/03/04/reorder1linked-list.jpg)

```
Input: head = [1,2,3,4]
Output: [1,4,2,3]

```

**Example 2:**

![](https://assets.leetcode.com/uploads/2021/03/09/reorder2-linked-list.jpg)

```
Input: head = [1,2,3,4,5]
Output: [1,5,2,4,3]
```

---

### 🧮 Approach / Algorithm Design

## **Solution**

---

### **Solution Bricks**

This problem is a combination of these three easy problems:

- [Middle of the Linked List](https://leetcode.com/problems/middle-of-the-linked-list).
- [Reverse Linked List](https://leetcode.com/problems/reverse-linked-list).
- [Merge Two Sorted Lists](https://leetcode.com/problems/merge-two-sorted-lists).

### **Approach 1: Reverse the Second Part of the List and Merge Two Sorted Lists**

**Overview**

- Find a middle node of the linked list.
    
    If there are two middle nodes, return the second middle node.
    
    Example: for the list `1->2->3->4->5->6`, the middle element is `4`.
    
- Once a middle node has been found, reverse the second part of the list.
    
    Example: convert `1->2->3->4->5->6` into `1->2->3->4` and `6->5->4`.
    
- Now merge the two sorted lists.
    
    Example: merge `1->2->3->4` and `6->5->4` into `1->6->2->5->3->4`.
    

![](https://leetcode.com/problems/reorder-list/Figures/143/overview.png)

Now let's check each algorithm part in more detail.

**Find a Middle Node**

Let's use two pointers, `slow` and `fast`. While the slow pointer moves one step forward `slow = slow.next`, the fast pointer moves two steps forward `fast = fast.next.next`, *i.e.* `fast` traverses twice as fast as `slow`. When the fast pointer reaches the end of the list, the slow pointer should be in the middle.

![](https://leetcode.com/problems/reorder-list/Figures/143/slow_fast.png)

**Reverse the Second Part of the List**

Let's traverse the list starting from the middle node `slow` and its virtual predecessor `None`. For each current node, save its neighbors: the previous node `prev` and the next node `tmp = curr.next`.

While you're moving along the list, change the node's next pointer to point to the previous node: `curr.next = prev`, and shift the current node to the right for the next iteration: `prev = curr`, `curr = tmp`.

![](https://leetcode.com/problems/reorder-list/Figures/143/reverse2.png)

**Merge Two Sorted Lists**

This algorithm is similar to the one for list reversal.

Let's pick the first node of each list - first and second, and save their successors. While you're traversing the list, set the first node's next pointer to point to the second node, and the second node's next pointer to point to the successor of the first node. For this iteration, the job is done, and for the next iteration, move to the previously saved nodes' successors.

![](https://leetcode.com/problems/reorder-list/Figures/143/first_second.png)

### 🎯 LeetCode Official Solution

```java
class Solution {
    public void reorderList(ListNode head) {
        if (head == null) return;

        // find the middle of linked list [Problem 876]
        // in 1->2->3->4->5->6 find 4
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }

        // reverse the second part of the list [Problem 206]
        // convert 1->2->3->4->5->6 into 1->2->3->4 and 6->5->4
        // reverse the second half in-place
        ListNode prev = null, curr = slow, tmp;
        while (curr != null) {
            tmp = curr.next;

            curr.next = prev;
            prev = curr;
            curr = tmp;
        }

        // merge two sorted linked lists [Problem 21]
        // merge 1->2->3->4 and 6->5->4 into 1->6->2->5->3->4
        ListNode first = head, second = prev;
        while (second.next != null) {
            tmp = first.next;
            first.next = second;
            first = tmp;

            tmp = second.next;
            second.next = first;
            second = tmp;
        }
    }
}
```

### ⏳ Complexity Analysis

- Time complexity: O(*N*). There are three steps here. To identify the middle node takes O(*N*) time. To reverse the second part of the list, one needs *N*/2 operations. The final step, to merge two lists, requires *N*/2 operations as well. In total, that results in O(*N*) time complexity.
- Space complexity: O(1), since we do not allocate any additional data structures.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
  public void reorderList(ListNode head) {

    // Find mid node
    ListNode midNode = getMidNode(head);

    // Reverse head2
    ListNode rev = reverseNode(midNode);

    // Pick one from first and one from second
    ListNode first = head;
    ListNode sec = rev;
    ListNode tmp = null;
    while (sec.next != null) {
      tmp = first.next;
      first.next = sec;
      first = tmp;

      tmp = sec.next;
      sec.next = first;
      sec = tmp;
    }
  }

  public ListNode getMidNode(ListNode head) {

    ListNode slow = head;
    ListNode fast = head;
    while (fast != null && fast.next != null) {
      slow = slow.next;
      fast = fast.next.next;
    }
    return slow;
  }

  public ListNode reverseNode(ListNode head) {
    if (head == null || head.next == null) {
      return head;
    }
    ListNode c1 = head;
    ListNode c2 = c1.next;
    ListNode c3 = null;
    c1.next = null;
    while (c2 != null) {
      c3 = c2.next;
      c2.next = c1;
      c1 = c2;
      c2 = c3;
    }
    return c1;
  }

}
```