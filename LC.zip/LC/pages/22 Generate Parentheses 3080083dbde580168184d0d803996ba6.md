# 22. Generate Parentheses

LeetCode URL: https://leetcode.com/problems/generate-parentheses
Approach: If LeftCount < n → add “(” and if rightCount < leftCount → add “)”. Use StringBuilder(more optimal, but it will need deleteCharAt(last).
Coding Pattern: Subsets
Company: Amazon, Google, Meta
Date Solved: February 11, 2026
Difficulty Level: Medium
Files & media: https://drive.google.com/file/d/1oh-KaVk8bENC7wsU9z2VUUkcyqIek4bL/view?usp=sharing
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: Catalan Number
Space Complexity: O(n)
Topic: Backtracking

### 🐞 Problem Statement

Given `n` pairs of parentheses, write a function to *generate all combinations of well-formed parentheses*.

**Example 1:**

```
Input: n = 3
Output: ["((()))","(()())","(())()","()(())","()()()"]
```

**Example 2:**

```
Input: n = 1
Output: ["()"]
```

**Constraints:**

- `1 <= n <= 8`

---

### 🧮 Approach / Algorithm Design

**Video Solution**

[https://drive.google.com/file/d/1oh-KaVk8bENC7wsU9z2VUUkcyqIek4bL/view?usp=sharing](https://drive.google.com/file/d/1oh-KaVk8bENC7wsU9z2VUUkcyqIek4bL/view?usp=sharing)

### **Approach: Backtracking, Keep Candidate Valid**

### **Intuition**

> If you are not familiar with backtracking, you can refer to our [Backtracking Explore Card](https://leetcode.com/explore/learn/card/recursion-ii/472/backtracking/) for more information.
> 

The previous approach of generating all possible strings of length `2n` and checking each one is simple but inefficient, as it generates many invalid strings that must be checked.

A better approach is to use backtracking to generate only valid strings. This involves recursively building strings of length `2n` and checking their validity as we go. In case the current string is invalid, we will not continue the recursive process on it. Instead, we will backtrack to the previous valid string on the recursive path. This approach allows us to focus only on generating valid strings, thus saving us time and resources. We continue the recursion only on the valid strings until we reach the ones of length `2n`.

As shown in the picture below: `)` is an invalid string, so every string prefixed with it is also invalid, and we can just drop it.

![img](https://leetcode.com/problems/generate-parentheses/Figures/22/5.png)

To ensure that the current string is always valid during the backtracking process, we need two variables `left_count` and `right_count` that record the number of left and right parentheses in it, respectively.

Therefore, we can define our backtracking function as `backtracking(cur_string, left_count, right_count)` that takes the current string, the number of left parentheses, and the number of right parentheses as arguments. This function will build valid combinations of parentheses of length `2n` recursively.

The function adds more parentheses to `cur_string` only when certain conditions are met:

- If `left_count < n`, it suggests that a left parenthesis can still be added, so we add one left parenthesis to `cur_string`, creating a new string `new_string = cur_string + (`, and then call `backtracking(new_string, left_count + 1, right_count)`.
- If `left_count > right_count`, it suggests that a right parenthesis can be added to match a previous unmatched left parenthesis, so we add one right parenthesis to `cur_string`, creating a new string `new_string = cur_string + )`, and then call `backtracking(new_string, left_count, right_count + 1)`.

This function ensures that the generated string of length `2n` is valid, and adds it directly to the answer. By only generating valid strings, we can avoid wasting time checking invalid strings.

### **Algorithm**

1. Initialize an empty list `answer` to store the valid strings.
2. Define `backtracking(cur_string, left_count, right_count)` to generate valid strings recursively.
    - If `len(cur_string) = 2n`, add it to `answer` and return.
    - If `left_count < n`, add `(` to `cur_string` and move on to `backtracking(new_string, left_count + 1, right_count)`.
    - If `left_count > right_count`, add `)` to `cur_string` and move on to `backtracking(new_string, left_count, right_count + 1)`.
3. Call `backtracking` on empty string (`backtracking("", 0, 0)`) and return `answer` once the backtracking process is complete.

### 🎯 LeetCode Official Solution

```java
class Solution {
    public List<String> generateParenthesis(int n) {
        List<String> answer = new ArrayList<>();
        backtracking(answer, new StringBuilder(), 0, 0, n);

        return answer;
    }

    private void backtracking(
        List<String> answer,
        StringBuilder curString,
        int leftCount,
        int rightCount,
        int n
    ) {
        if (curString.length() == 2 * n) {
            answer.add(curString.toString());
            return;
        }
        if (leftCount < n) {
            curString.append("(");
            backtracking(answer, curString, leftCount + 1, rightCount, n);
            curString.deleteCharAt(curString.length() - 1);
        }
        if (leftCount > rightCount) {
            curString.append(")");
            backtracking(answer, curString, leftCount, rightCount + 1, n);
            curString.deleteCharAt(curString.length() - 1);
        }
    }
}
```

### ⏳ Complexity Analysis

![image.png](image%204.png)

- Space complexity: *O*(*n*)
    - The space complexity of a recursive call depends on the maximum depth of the recursive call stack, which is 2*n*. As each recursive call either adds a left parenthesis or a right parenthesis, and the total number of parentheses is 2*n*. Therefore, at most *O*(*n*) levels of recursion will be created, and each level consumes a constant amount of space.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
    public List<String> generateParenthesis(int n) {

        List<String> result = new ArrayList<>();
        backtracking(result, new StringBuilder(), 0, 0, n);

        return result;
    }

    private void backtracking(List<String> result, StringBuilder str, int leftCount, int rightCount, int n) {

        if (str.length() == (2 * n)) {
            result.add(str.toString());
            return;
        }
        if (leftCount < n) {
            backtracking(result, str.append("("), leftCount + 1, rightCount, n);
            str.deleteCharAt(str.length() - 1);
        }
        if (rightCount < leftCount) {
            backtracking(result, str.append(")"), leftCount, rightCount + 1, n);
            str.deleteCharAt(str.length() - 1);
        }
    }

}
```