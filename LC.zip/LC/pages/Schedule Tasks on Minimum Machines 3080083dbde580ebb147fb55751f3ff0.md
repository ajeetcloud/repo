# Schedule Tasks on Minimum Machines

Approach: Sort the array with startTimes. Create a PQ(MinHeap) to hold endTime. Iterate on array and not on PQ. If current task’s start is after peek(endTime), poll() from heap. Add the currentEnd to Heap. HeapSize at the end is the answer.
Coding Pattern: Two Heaps
Company: Google
Date Solved: February 18, 2026
Difficulty Level: Medium
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n log n)
Space Complexity: O(n)

### 🐞 Problem Statement

We are given an input array, `tasks`, where `tasks[i]` =[starti,endi]=[*starti*,*endi*] represents the start and end times of n*n* tasks. Our goal is to schedule these tasks on machines given the following criteria:

1. A machine can execute only one task at a time.
2. A machine can begin executing a new task immediately after completing the previous one.
3. An unlimited number of machines are available.

Find the *minimum number of machines* required to complete these *n* tasks.

**Constraints:**

- n==*n*== `tasks.length`
- 1≤1≤ `tasks.length` ≤103≤103
- 0≤0≤ `tasksi.start` << `tasksi.end` ≤104≤104

![image.png](image%205.png)

---

### 🧮 Approach / Algorithm Design

The core intuition for solving this problem is to allocate tasks to the minimum number of machines by reusing machines whenever possible. The algorithm efficiently manages machine availability by sorting tasks by their start times and using a min heap to track end times. If the earliest available machine (top of the heap) finishes before or as a task starts, it is reused and removed from the heap. Otherwise, a new machine is allocated, and the current task’s end time is pushed into the heap. The heap size at the end represents the minimum number of machines required.

Using the intuition above, we implement the algorithm as follows:

1. Sort the `tasks` array by the start time of each task to process them in chronological order.
2. Initialize a min heap (`machines`) to keep track of the end times of tasks currently using machines.
3. Iterate over each task in the sorted `tasks` array.
    1. Extract the start and end times of the current task.
    2. Check if the machine with the earliest finish time is free, i.e., top of `machines` is less than or equal to the current task’s start time. If it is, remove it from the heap, as the machine can be reused.
    3. Push the end time of the current task into the heap, indicating that a machine is now in use until that time.
4. After processing all tasks, return the size of the heap, which represents the minimum number of machines required.

### 🎯 LeetCode Official Solution

```java
public static int minimumMachines(int[][] tasks) {
        Arrays.sort(tasks, Comparator.comparingInt(a -> a[0]));

        PriorityQueue<Integer> machines = new PriorityQueue<>();

        for (int[] task : tasks) {
            int start = task[0];
            int end = task[1];

            if (!machines.isEmpty() && machines.peek() <= start)
                machines.poll();

            machines.add(end);
        }

        return machines.size();
    }
```

### ⏳ Complexity Analysis

### **Time complexity**

The time complexity of the above algorithm is *O*(*n*log*n*), where n*n* is the number of tasks represented by the length of the `tasks` array. This is because:

- Sorting the array takes *O*(*n*log*n*).
- The total cost for heap operations is *O*(*n*log*n*) because we process n*n* tasks, and each operation on the min-heap has a time complexity of *O*(log*n*).

Therefore, the overall time complexity is *O*(*n*log*n*).

### **Space complexity**

The algorithm’s space complexity is O(n). *O*(*n*) because the min heap can grow up to a maximum size of *n* if every task requires a separate machine.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
public static int minimumMachines(int[][] tasks) {
      
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        Arrays.sort(tasks, (a,b) -> Integer.compare(a[0], b[0]));        
        
        pq.offer(tasks[0][1]);
        for (int i = 1; i < tasks.length; i++) {
               int[] task = tasks[i];
               int startTime = task[0];
               int top = pq.peek();
               if (startTime >= top) {
                   pq.poll();
               }
               pq.offer(task[1]);
        }
        return pq.size();
    }
```