# 57. Insert Interval

LeetCode URL: https://leetcode.com/problems/insert-interval
Approach: Use BinarySearch to figure out insertion index(i) of new interval. Create a new list. Add elements to this list from array before i, then add new interval, then add elements after i position. From here its merge interval problem.
Coding Pattern: Merge Intervals
Company: Amazon, Apple, Google
Date Solved: April 24, 2025
Difficulty Level: Medium
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n)
Space Complexity: O(n)
Topic: Arrays

### 🐞 Problem Statement

You are given an array of non-overlapping intervals `intervals` where `intervals[i] = [starti, endi]` represent the start and the end of the `ith` interval and `intervals` is sorted in ascending order by `starti`. You are also given an interval `newInterval = [start, end]` that represents the start and end of another interval.

Insert `newInterval` into `intervals` such that `intervals` is still sorted in ascending order by `starti` and `intervals` still does not have any overlapping intervals (merge overlapping intervals if necessary).

Return `intervals` *after the insertion*.

**Note** that you don't need to modify `intervals` in-place. You can make a new array and return it.

---

### 🧮 Approach / Algorithm Design

### **Overview**

We are given a sorted list of non-overlapping `intervals` and a `newInterval`. The task is to insert the `newInterval` into the `intervals` while maintaining sorted order and ensuring no overlapping intervals. If there is any overlap, the overlapping intervals should be merged. In the end, return the intervals list with the addition of the new intervals.

Two key observations are crucial for this problem:

1. The given intervals are already sorted in ascending order based on the start values.
2. Initially, the intervals are non-overlapping, but inserting a new interval might lead to overlaps that need resolution by merging while maintaining sorted order.

To solve this problem, we break it into three cases when comparing the current interval with the new interval:

Case 1. The current interval ends before the new interval starts.

Case 2. There is an overlap, and the intervals need merging.

Case 3. The current interval starts after the new interval ends.

A visual representation below illustrates all three scenarios:

![](https://leetcode.com/problems/insert-interval/Figures/57_re/1.png)

Now let us consider the given problem description example with `intervals` and a `newInterval`:

```
intervals = [[1, 3], [6, 9]]
newInterval = [2, 5]
```

The first interval starts at 1 and ends at 3, while the second interval starts at 6 and ends at 9. The goal is to insert the `newInterval` into the existing list of `intervals`, maintaining sorted order.

Upon analysis, we observe that the `newInterval` [2, 5] overlaps with the first interval [1, 3] because 2 is less than 3. Now, since we know the intervals need to be merged, we must ensure the merged interval covers the entire overlapping region.

To achieve this, we take the maximum of the end of the first interval and the end of the new interval, as well as the minimum of the start of the first interval and the start of the new interval. Therefore, the merged interval becomes `[min(1, 2), max(3, 5)] = [1, 5]`.

Moving on to the second interval [6, 9], its starting point (6) comes after the new interval's ending point (5). There is no overlap between them. Therefore, the second interval remains unchanged.

| **Original Intervals** | **New Interval** | **Action** | **Resulting Intervals** |
| --- | --- | --- | --- |
| [1,3] | [2,5] | New interval overlaps with the first interval [1,3]. Merge intervals by taking [min(1, 2), max(3, 5)] = [1, 5]. | [1,5] |
| [6,9] |  | No overlap with the new interval [2,5]. Interval remains unchanged. | [6,9] |

In conclusion, the final result is [[1, 5], [6, 9]], representing the intervals after inserting and merging the new interval [2, 5].

In a concrete business context, this problem may be presented as follows: Suppose we have an array representing video watch times, where each segment consists of the start and stop times of a user watching a video. The task is to calculate the total number of unique minutes watched across all the video segments. This is fundamentally the same question.

> We recommend solving Merge Intervals problem before attempting this question, as it provides valuable insights into pattern recognition. This question is an extension of the Merge Intervals concept, building upon the same principles.
> 

### **Approach 2: Binary Search**

### **Intuition**

To apply binary search to a problem, a crucial requirement is that the input should have a monotonically increasing or decreasing nature. In our given scenario, it is explicitly stated that the input is already sorted with respect to the start value, indicating a monotonically increasing order. Therefore, we can confidently consider applying binary search.

### **1. Finding the Insertion Position**

As the intervals are sorted by start value, we perform a binary search comparing the starting point of the current interval (`intervals[mid][0]`) with the starting point of the new interval (`target`). If `intervals[mid][0]` is less than the target, it indicates that the insertion point should be to the right of the current position. Consequently, we update `left` to `mid + 1`. If it's greater, the insertion point should be to the left, so we update `right` to `mid - 1`. This process continues until `left` becomes greater than `right`, revealing the correct insertion position.

### **2. Handling Merging**

1. If `res` is empty or the end of the last interval in `res` is less than the starting point of the current interval, it indicates there is no overlap before merging. The current interval is directly added to `res` in such cases.
2. If an overlap is detected, signifying the need for merging, the current interval is merged with the last interval in `res`. The end of the last interval in `res` is updated to the maximum of its current end and the end of the current interval.

### **Algorithm**

- If `intervals` is empty, it means there are no existing intervals, so we can simply return a array containing the `newInterval`.
- Perform a binary search to find the correct position to insert the new interval in the `intervals` array. It updates the values of `left` and `right` based on the comparison of the target value with the first element of the interval at the middle index.
    - Initialize the variables `target` with the starting point of `newInterval` (i.e., `newInterval[0]`), `left` with 0, and `right` with `n - 1` to define the search space in the `intervals` array.
    - Perform a binary search by repeatedly dividing the search space in half until `left` is greater than `right`.
    - Calculate the middle index `mid` as the average of `left` and `right`.
    - If the start of the interval at index `mid` is less than the target value, update `left` to `mid + 1` to search the right half of the search space. Otherwise, update `right` to `mid - 1` to search the left half of the search space.
    - The search updates `left` and `right` until they converge to the correct position. Repeat until `left` is greater than `right`.
- Use `intervals.insert(intervals.begin() + left, newInterval)` to insert the `newInterval` at the correct position.
- Initialize an empty array `res` to store the result.
- Iterate through the sorted intervals.
    - Check if `res` is empty or if the end of the last interval in `res` is less than the start of the current interval. If either condition is true, add the current interval to `res`.
    - If there is an overlap, update the endpoint of the last interval in `res` to cover the current interval. This step ensures that non-overlapping intervals are added directly, and overlapping intervals are merged.
- The final merged and inserted intervals are stored in the `res` array, which is then returned.

### 🎯 LeetCode Official Solution

```java
class Solution {
    public int[][] insert(int[][] intervals, int[] newInterval) {
        // If the intervals vector is empty, return a vector containing the newInterval
        if (intervals.length == 0) {
            return new int[][] { newInterval };
        }

        int n = intervals.length;
        int target = newInterval[0];
        int left = 0, right = n - 1;

        // Binary search to find the position to insert newInterval
        while (left <= right) {
            int mid = (left + right) / 2;
            if (intervals[mid][0] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        // Insert newInterval at the found position
        List<int[]> result = new ArrayList<>();
        for (int i = 0; i < left; i++) {
            result.add(intervals[i]);
        }
        result.add(newInterval);
        for (int i = left; i < n; i++) {
            result.add(intervals[i]);
        }

        // Merge overlapping intervals
        List<int[]> merged = new ArrayList<>();
        for (int[] interval : result) {
            // If res is empty or there is no overlap, add the interval to the result
            if (
                merged.isEmpty() ||
                merged.get(merged.size() - 1)[1] < interval[0]
            ) {
                merged.add(interval);
                // If there is an overlap, merge the intervals by updating the end of the last interval in res
            } else {
                merged.get(merged.size() - 1)[1] = Math.max(
                    merged.get(merged.size() - 1)[1],
                    interval[1]
                );
            }
        }

        return merged.toArray(new int[0][]);
    }
}
```

### ⏳ Complexity Analysis

Let *N* be the number of intervals.

- Time complexity: *O*(*N*)
    
    The binary search for finding the position to insert the `newInterval` has a time complexity of *O*(log*N*). However, the insertion of the `newInterval` into the list may take *O*(*N*) time in the worst case, as it could involve shifting elements within the list. Consequently, the overall time complexity is *O*(*N*+log*N*), which simplifies to *O*(*N*).
    
- Space complexity: *O*(*N*)
    
    We use the additional space to store the result (`res`) and perform calculations using `res,` so it does count towards the space complexity. In the worst case, the size of `res` will be proportional to the number of intervals in the input list.
    

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
  public int[][] insert(int[][] intervals, int[] newInterval) {
    
    List<int[]> list = new ArrayList<>();
    int find = newInterval[0];
    int left = 0;
    int right = intervals.length - 1;
    while (left <= right) {
      int mid = (left + right) / 2;
      if (intervals[mid][0] < find) {
        left = mid + 1;
      } else {
        right = mid - 1;
      }
    }
    // left is the insert position
    for (int i = 0; i < left; i++) {
      list.add(intervals[i]);
    }
    list.add(newInterval);
    for (int i = left; i < intervals.length; i++) {
      list.add(intervals[i]);
    }
    // merge interval
    LinkedList<int[]> result = new LinkedList<>();
    result.add(list.get(0));
    for (int i = 1; i < list.size(); i++) {
      int[] interval = list.get(i);
      int[] lastResult = result.getLast();
      if (interval[0] <= lastResult[1]) {
        // merge
        lastResult[1] = Math.max(lastResult[1], interval[1]);
      } else {
        result.add(interval);
      }
    }
    return result.toArray(new int[result.size()][]);
  }
}
```