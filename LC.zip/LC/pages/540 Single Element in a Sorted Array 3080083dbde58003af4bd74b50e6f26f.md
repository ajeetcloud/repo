# 540. Single Element in a Sorted Array

LeetCode URL: https://leetcode.com/problems/single-element-in-a-sorted-array
Approach: Check logic of even and odd indices before and after encountering a single ement.
Coding Pattern: Modified Binary Search
Company: Amazon, Google
Date Solved: January 23, 2026
Difficulty Level: Medium
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(log n)
Space Complexity: O(1)
Topic: Binary Search

### 🐞 Problem Statement

You are given a sorted array consisting of only integers where every element appears exactly twice, except for one element which appears exactly once.

Return *the single element that appears only once*.

Your solution must run in `O(log n)` time and `O(1)` space.

**Example 1:**

```
Input: nums = [1,1,2,3,3,4,4,8,8]
Output: 2
```

**Example 2:**

```
Input: nums = [3,3,7,7,10,11,11]
Output: 10
```

**Constraints:**

- `1 <= nums.length <= 105`
- `0 <= nums[i] <= 105`

---

### 🧮 Approach / Algorithm Design

### **Approach 1: Binary Search**

**Intuition**

It makes sense to try and convert the linear search into a binary search. In order to use binary search, we need to be able to look at the middle item and then determine whether the solution is the middle item, or to the left, or to the right. The key observation to make is that the starting array must always have an odd number of elements (be odd-lengthed), because it has one element appearing once, and all the other elements appearing twice.

![An array with the elements 1, 1, 4, 4, 5, 5, 6, 6, 8, 9, 9](https://leetcode.com/problems/single-element-in-a-sorted-array/Figures/540/example1.png)

Here is what happens when we remove a *pair* from the center. We are left with a left subarray and a right subarray.

![An array with the elements 1, 1, 4, 4, 5, 5, 6, 6, 8, 9, 9. The 5's are crossed out.](https://leetcode.com/problems/single-element-in-a-sorted-array/Figures/540/example2.png)

Like the original array, the subarray containing the single element must be odd-lengthed. The subarray *not* containing it must be even-lengthed. So by taking a pair out of the middle and then calculating which side is now odd-lengthed, we have the information needed for binary search.

**Algorithm**

We start by setting `lo` and `hi` to be the lowest and highest index (inclusive) of the array, and then iteratively halve the array until we find the single element or until there is only one element left. We know that if there is only one element in the search space, it must be the single element, so should terminate the search.

On each loop iteration, we find `mid`, and determine the odd/ evenness of the sides and save it in a variable called `halvesAreEven`. By then looking at which half the middle element's *partner* is in (either last element in the left subarray or first element in the right subarray), we can decide which side is now (or remained) odd-lengthed and set `lo` and `hi` to cover the part of the array we now know the single element must be in.

The trickiest part is ensuring we update `lo` and `hi` correctly based on the values of `mid` and `halvesAreEven`. These diagrams should help you understand the cases. When solving problems like this, it's often good to draw a diagram and think really carefully about it to avoid off-by-one errors. Avoid using a guess and check approach.

*Case 1: Mid’s partner is to the right, and the halves were originally even.*

The right side *becomes* odd-lengthed because we removed `mid`'s partner from it. We need to set `lo` to `mid + 2` so that the remaining array is the part above `mid`'s partner.

![fig](https://leetcode.com/problems/single-element-in-a-sorted-array/Figures/540/case1.png)

*Case 2: Mid’s partner is to the right, and the halves were originally odd.*

The left side *remains* odd-lengthed. We need to set `hi` to `mid - 1` so that the remaining array is the part below `mid`.

![fig](https://leetcode.com/problems/single-element-in-a-sorted-array/Figures/540/case2.png)

*Case 3: Mid’s partner is to the left, and the halves were originally even.*

The left side *becomes* odd-lengthed because we removed `mid`'s partner from it. We need to set `hi` to `mid - 2` so that the remaining array is the part below `mid`'s partner.

![fig](https://leetcode.com/problems/single-element-in-a-sorted-array/Figures/540/case3.png)

*Case 4: Mid’s partner is to the left, and the halves were originally odd.*

The right side *remains* odd-lengthed. We need to set `lo` to `mid + 1` so that the remaining array is the part above `mid`.

![fig](https://leetcode.com/problems/single-element-in-a-sorted-array/Figures/540/case4.png)

Another interesting observation you might have made is that this algorithm will still work even if the array isn't fully sorted. As long as pairs are always grouped together in the array (for example, `[10, 10, 4, 4, 7, 11, 11, 12, 12, 2, 2]`), it doesn't matter what order they're in. Binary search worked for this problem because we knew the subarray with the single number is always odd-lengthed, not because the array was fully sorted numerically. We commonly call this an *invariant*, something that is always true (i.e. "The array containing the single element is always odd-lengthed"). Be on the lookout for invariants like this when solving array problems, as binary search is very flexibile!

**Complexity Analysis**

- Time complexity : *O*(log*n*). On each iteration of the loop, we're *halving* the number of items we still need to search.
- Space complexity : *O*(1). We are only using constant space to keep track of where we are in the search.

### **Approach 2: Binary Search on Evens Indexes Only**

It turns out that we only need to binary search on the even indexes. This approach is more elegant than the last, although both are good solutions.

**Intuition**

The single element is at the *first* even index *not* followed by its pair. We used this property in the linear search algorithm, where we iterated over all of the *even indexes* until we encountered the first one not followed by its pair.

Instead of linear searching for this index though, we can binary search for it.

After the single element, the pattern changes to being odd indexes followed by their pair. This means that the single element (an even index) and all elements after it are even indexes *not* followed by their pair. Therefore, given any even index in the array, we can easily determine whether the single element is to the left or to the right.

**Algorithm**

We need to set up the binary search variables and loop so that we are only considering *even* indexes. The last index of an odd-lengthed array is always even, so we can set `lo` and `hi` to be the start and end of the array.

We need to make sure our `mid` index is *even*. We can do this by dividing `lo` and `hi` in the usual way, but then *decrementing* it by `1` if it is odd. This also ensures that if we have an even number of even indexes to search, that we are getting the *lower middle* (*incrementing* by 1 here would not work, it'd lead to an infinite loop as the search space would not be reduced in some cases).

Then we check whether or not the `mid` index is the same as the one after it.

- *If it is*, then we know that `mid` is not the single element, and that the single element must be at an even index *after* `mid`. Therefore, we set `lo` to be `mid + 2`. It is `+2` rather than the usual `+1` because we want it to point at an even index.
- *If it is not*, then we know that the single element is either at `mid`, or at some index *before* `mid`. Therefore, we set `hi` to be mid.

Once `lo == hi`, the search space is down to 1 element, and this must be the single element, so we return it.

**Complexity Analysis**

- Time complexity : *O*(log *n/2*)=*O*(log*n*). Same as the binary search above, except we are only binary searching half the elements, rather than all of them.
- Space complexity : *O*(1). Same as the other approaches. We are only using constant space to keep track of where we are in the search.

### 🎯 LeetCode Official Solution

```java
class Solution {
    public int singleNonDuplicate(int[] nums) {
        int lo = 0;
        int hi = nums.length - 1;
        while (lo < hi) {
            int mid = lo + (hi - lo) / 2;
            if (mid % 2 == 1) mid--;
            if (nums[mid] == nums[mid + 1]) {
                lo = mid + 2;
            } else {
                hi = mid;
            }
        }
        return nums[lo];
    }
}
```

### ⏳ Complexity Analysis

- Time complexity : *O*(log *n/2*)=*O*(log*n*). Same as the binary search above, except we are only binary searching half the elements, rather than all of them.
- Space complexity : *O*(1). Same as the other approaches. We are only using constant space to keep track of where we are in the search.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
    public int singleNonDuplicate(int[] nums) {
        int left = 0;
        int right = nums.length - 1;
        while (left < right) {
            int midEven = left + (right - left) / 2;
            if (midEven % 2 == 1) {
                midEven--;
            }
            if (nums[midEven] == nums[midEven + 1]) {
                // answer is in second half
                left = midEven + 2;
            } else {
                right = midEven;
            }
        }
        return nums[left]; 
    }
}
```