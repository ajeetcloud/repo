# Problem Name

### 🐞 Problem Statement

---

### 🧮 Approach / Algorithm Design

### 🎯 LeetCode Official Solution

```java

```

### ⏳ Complexity Analysis

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
// LeetCode accepted Code goes here
```