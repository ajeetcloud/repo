# 56. Merge Intervals

LeetCode URL: https://leetcode.com/problems/merge-intervals
Approach: Sort the array. Store results in LinkedList(adding to last is easy). Compare ith interval to (i-1)th interval for. If overlap update (i-1)th interval, else add ith interval.
Coding Pattern: Merge Intervals
Company: Amazon, Google, Meta
Date Solved: April 23, 2025
Difficulty Level: Medium
Files & media: https://drive.google.com/file/d/1vr_203yUEcVgPlWFi1nKrEKCLHpsFFeD/view?usp=sharing
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n log n)
Space Complexity: O(n)
Topic: Arrays

### 🐞 Problem Statement

Given an array of `intervals` where `intervals[i] = [starti, endi]`, merge all overlapping intervals, and return *an array of the non-overlapping intervals that cover all the intervals in the input*.

**Example 1:**

```
Input: intervals = [[1,3],[2,6],[8,10],[15,18]]
Output: [[1,6],[8,10],[15,18]]
Explanation: Since intervals [1,3] and [2,6] overlap, merge them into [1,6].
```

**Example 2:**

```
Input: intervals = [[1,4],[4,5]]
Output: [[1,5]]
Explanation: Intervals [1,4] and [4,5] are considered overlapping.
```

---

### 🧮 Approach / Algorithm Design

### **Approach 1: Connected Components**

**Intuition**

If we draw a graph (with intervals as nodes) that contains undirected edges between all pairs of intervals that overlap, then all intervals in each *connected component* of the graph can be merged into a single interval.

**Algorithm**

With the above intuition in mind, we can represent the graph as an adjacency list, inserting directed edges in both directions to simulate undirected edges. Then, to determine which connected component each node is in, we perform graph traversals from arbitrary unvisited nodes until all nodes have been visited. To do this efficiently, we store visited nodes in a `Set`, allowing for constant time containment checks and insertion. Finally, we consider each connected component, merging all of its intervals by constructing a new `Interval` with `start` equal to the minimum start among them and `end` equal to the maximum end.

This algorithm is correct simply because it is basically the brute force solution. We compare every interval to every other interval, so we know exactly which intervals overlap. The reason for the connected component search is that two intervals may not directly overlap, but might overlap indirectly via a third interval. See the example below to see this more clearly.

![](https://leetcode.com/problems/merge-intervals/Figures/56/component.png)

Although (1, 5) and (6, 10) do not directly overlap, either would overlap with the other if first merged with (4, 7). There are two connected components, so if we merge their nodes, we expect to get the following two merged intervals:

(1, 10), (15, 20)

### **Approach 2: Sorting**

**Video Solution**

[[https://drive.google.com/file/d/1vr_203yUEcVgPlWFi1nKrEKCLHpsFFeD/view?usp=sharing](https://drive.google.com/file/d/1vr_203yUEcVgPlWFi1nKrEKCLHpsFFeD/view?usp=sharing)](https://drive.google.com/file/d/1vr_203yUEcVgPlWFi1nKrEKCLHpsFFeD/view?usp=sharing)

**Intuition**

If we sort the intervals by their `start` value, then each set of intervals that can be merged will appear as a contiguous "run" in the sorted list.

**Algorithm**

First, we sort the list as described. Then, we insert the first interval into our `merged` list and continue considering each interval in turn as follows: If the current interval begins *after* the previous interval ends, then they do not overlap and we can append the current interval to `merged`. Otherwise, they do overlap, and we merge them by updating the `end` of the previous interval if it is less than the `end` of the current interval.

A simple proof by contradiction shows that this algorithm always produces the correct answer. First, suppose that the algorithm at some point fails to merge two intervals that should be merged. This would imply that there exists some triple of indices *i*, *j*, and *k* in a list of intervals ints such that *i*<*j*<*k* and (ints[i], ints[k]) can be merged, but neither (ints[i], ints[j]) nor (ints[j], ints[k]) can be merged. From this scenario follow several inequalities:

ints[i].end<ints[j].startints[j].end<ints[k].startints[i].end≥ints[k].start

We can chain these inequalities (along with the following inequality, implied by the well-formedness of the intervals: ints[j].start≤ints[j].end) to demonstrate a contradiction:

ints[i].end<ints[j].start≤ints[j].end<ints[k].startints[i].end≥ints[k].start

Therefore, all mergeable intervals must occur in a contiguous run of the sorted list.

![](https://leetcode.com/problems/merge-intervals/Figures/56/sort.png)

Consider the example above, where the intervals are sorted, and then all mergeable intervals form contiguous blocks.

### 🎯 LeetCode Official Solution

```java
class Solution {
    public int[][] merge(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> Integer.compare(a[0], b[0]));
        LinkedList<int[]> merged = new LinkedList<>();
        for (int[] interval : intervals) {
            // if the list of merged intervals is empty or if the current
            // interval does not overlap with the previous, simply append it.
            if (merged.isEmpty() || merged.getLast()[1] < interval[0]) {
                merged.add(interval);
            }
            // otherwise, there is overlap, so we merge the current and previous
            // intervals.
            else {
                merged.getLast()[1] = Math.max(
                    merged.getLast()[1],
                    interval[1]
                );
            }
        }
        return merged.toArray(new int[merged.size()][]);
    }
}
```

### ⏳ Complexity Analysis

- Time complexity : *O*(*n*log*n*)
    
    Other than the `sort` invocation, we do a simple linear scan of the list, so the runtime is dominated by the *O*(*n*log*n*) complexity of sorting.
    
- Space complexity : *O*(log*N*) (or *O*(*n*))
    
    If we can sort `intervals` in place, we do not need more than constant additional space, although the sorting itself takes *O*(log*n*) space. Otherwise, we must allocate linear space to store a copy of `intervals` and sort that.
    

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
  public int[][] merge(int[][] intervals) {
    Arrays.sort(intervals, (a, b) -> Integer.compare(a[0], b[0]));
    LinkedList<int[]> result = new LinkedList<>();
    result.add(intervals[0]);
    for (int i = 1; i < intervals.length; i++) {
      int[] interval = intervals[i];
      int[] lastResult = result.getLast();
      if (interval[0] <= lastResult[1]) {
        // overlap -> merge
        lastResult[1] = Math.max(lastResult[1], interval[1]);
      } else {
        result.add(interval);
      }
    }
    return result.toArray(new int[result.size()][]);
  }
}
```