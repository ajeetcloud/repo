# 187. Repeated DNA Sequences

LeetCode URL: https://leetcode.com/problems/repeated-dna-sequences
Approach: Use Rabin-Karp Rolling hash method to assign characters(A:0, B:1…), calculate polynomial hash then
Coding Pattern: Sliding Window
Company: Amazon, Google
Date Solved: March 8, 2025
Difficulty Level: Medium
Frequency of Revision: Weekly
Problem Progress: Completed
Time Complexity: O(n)
Space Complexity: O(n)
Topic: Sliding Window

### 🐞 Problem Statement

The **DNA sequence** is composed of a series of nucleotides abbreviated as `'A'`, `'C'`, `'G'`, and `'T'`.

- For example, `"ACGAATTCCG"` is a **DNA sequence**.

When studying **DNA**, it is useful to identify repeated sequences within the DNA.

Given a string `s` that represents a **DNA sequence**, return all the **`10`-letter-long** sequences (substrings) that occur more than once in a DNA molecule. You may return the answer in **any order**.

**Example 1:**

```
Input: s = "AAAAACCCCCAAAAACCCCCCAAAAAGGGTTT"
Output: ["AAAAACCCCC","CCCCCAAAAA"]
```

**Example 2:**

```
Input: s = "AAAAAAAAAAAAA"
Output: ["AAAAAAAAAA"]
```

---

### 🧮 Approach / Algorithm Design

## **Solution**

---

### **Overview**

The follow-up here is to solve the same problem for arbitrary sequence length *L*, and to check the situation when *L* is quite large. Hence let's use *L*=10 notation everywhere to ease the problem generalization.

> We will discuss three different ideas on how to proceed. They are all based on sliding window + hashset. The key point is how to implement a window slice.
> 

Linear-time window slice O(*L*) is simple, just take a substring. Overall that would result in O((*N*−*L*)*L*) time complexity and huge space consumption in the case of large sequences.

Constant-time slice O(1) is where the fun starts because the way you choose will show your actual background.There are two ways to proceed:

- Rabin-Karp = constant-time slice using a rolling hash algorithm.
- Bit manipulation = constant-time slice using bitmasks.

Last two approaches have O(*N*−*L*) time complexity and moderate space consumption even in the case of large sequences.

![image.png](image%201.png)

---

### **Approach 1: Linear-time Slice Using Substring + HashSet**

The idea is straightforward :

- Move a sliding window of length L along the string of length N.
- Check if the sequence in the sliding window is in the hashset of already seen sequences.
    - If yes, the repeated sequence is right here. Update the output.
    - If not, save the sequence in the sliding window in the hashset.

![image.png](image%202.png)

```java
class Solution {

    public List<String> findRepeatedDnaSequences(String s) {
        int L = 10, n = s.length();
        HashSet<String> seen = new HashSet(), output = new HashSet();

        // iterate over all sequences of length L
        for (int start = 0; start < n - L + 1; ++start) {
            String tmp = s.substring(start, start + L);
            if (seen.contains(tmp)) output.add(tmp);
            seen.add(tmp);
        }
        return new ArrayList<String>(output);
    }
}
```

**Complexity Analysis**

- Time complexity : O((*N*−*L*)*L*), that is O(*N*) for the constant *L*=10. In the loop executed *N*−*L*+1, one builds a substring of length *L*. Overall that results in O((*N*−*L*)*L*) time complexity.
- Space complexity : O((*N*−*L*)*L*) to keep the hashset, that results in O(*N*) for the constant *L*=10.

### **Approach 2: Rabin-Karp: Constant-time Slice Using Rolling Hash**

Rabin-Karp algorithm is used to perform a multiple pattern search. It's used for plagiarism detection and in bioinformatics to look for similarities in two or more proteins.

Detailed implementation of the Rabin-Karp algorithm for quite a complex case you could find in the article [Longest Duplicate Substring](https://leetcode.com/articles/longest-duplicate-substring/), we do a very basic implementation.

> The idea is to slice over the string and to compute the hash of the sequence in the sliding window, both in a constant time.
> 

Let's use the string `AAAAACCCCCAAAAACCCCCCAAAAAGGGTTT` as an example. First, convert the string to an integer array:

- 'A' -> 0, 'C' -> 1, 'G' -> 2, 'T' -> 3

`AAAAACCCCCAAAAACCCCCCAAAAAGGGTTT` -> `00000111110000011111100000222333`. Time to compute the hash for the first sequence of length L: `0000011111`. The sequence could be considered as a number in a [numeral system](https://en.wikipedia.org/wiki/Numeral_system) with the base 4 and hashed as

*h*0=∑*i*=0*L*−1*ci*4*L*−1−*i*

Here *c*0..4=0 and *c*5..9=1 are digits of `0000011111`.

Now let's consider the slice `AAAAACCCCC` -> `AAAACCCCCA`. For int arrays that means `0000011111` -> `0000111110`, to remove one leading 0 and add one trailing 0. One integer in, and one out, let's recompute the hash:

*h*1=(*h*0×4−*c*04*L*)+*cL*+1.

Voila, window slice, and hash recomputation are both done in a constant time.

**Algorithm**

- Iterate over the start position of the sequence: from 1 to *N*−*L*.
    - If `start == 0`, compute the hash of the first sequence `s[0: L]`.
    - Otherwise, compute the rolling hash from the previous hash value.
    - If the hash is in the hashset, one met a repeated sequence, time to update the output.
    - Otherwise, add hash in the hashset.
- Return output list.

### 🎯 LeetCode Official Solution

```java
class Solution {

    public List<String> findRepeatedDnaSequences(String s) {
        int L = 10, n = s.length();
        if (n <= L) return new ArrayList();

        // rolling hash parameters: base a
        int a = 4, aL = (int) Math.pow(a, L);

        // convert string to array of integers
        Map<Character, Integer> toInt = new HashMap() {
            {
                put('A', 0);
                put('C', 1);
                put('G', 2);
                put('T', 3);
            }
        };
        int[] nums = new int[n];
        for (int i = 0; i < n; ++i) nums[i] = toInt.get(s.charAt(i));

        int h = 0;
        Set<Integer> seen = new HashSet();
        Set<String> output = new HashSet();
        // iterate over all sequences of length L
        for (int start = 0; start < n - L + 1; ++start) {
            // compute hash of the current sequence in O(1) time
            if (start != 0) h =
                h * a - nums[start - 1] * aL + nums[start + L - 1];
            // compute hash of the first sequence in O(L) time
            else for (int i = 0; i < L; ++i) h = h * a + nums[i];

            // update output and hashset of seen sequences
            if (seen.contains(h)) output.add(s.substring(start, start + L));
            seen.add(h);
        }
        return new ArrayList<String>(output);
    }
}
```

### ⏳ Complexity Analysis

Time complexity : O(*N*−*L*), that is O(*N*) for the constant *L*=10. In the loop executed *N*−*L*+1 one builds a hash in a constant time, that results in O(*N*−*L*) time complexity.

- Space complexity : O(*N*−*L*) to keep the hashset, that results in O(*N*) for the constant *L*=10.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
public static List<String> findRepeatedDnaSequences(String s) {

        int k = 10;
        int length = s.length();
        if (k >= length) {
            return new ArrayList<>();
        }
        Map<Character, Integer> map = new HashMap<>();
        map.put('A', 0);
        map.put('C', 1);
        map.put('G', 2);
        map.put('T', 3);
        int a = 4;
        int start = 0;
        int end = start + k - 1;
        int h = 0;
        int p = k - 1;
        // calculate initial hash
        for (int i = 0; i <= end; i++) {
            char c = s.charAt(i);
            h += map.get(c) * (Math.pow(a, p));
            p--;
        }
        Set<Integer> seen = new HashSet<>();
        Set<String> results = new HashSet<>();
        seen.add(h);

        while (end <= length - 2) {
            char prevC = s.charAt(start);
            start++;
            end++;
            h = h - ((map.get(prevC)) * (int)(Math.pow(a, k - 1)));
            h *= a;
            char endC = s.charAt(end);
            h += ((map.get(endC)) * (int)(Math.pow(a, 0)));
            if (seen.contains(h)) {
                results.add(s.substring(start, start + k));
            }
            seen.add(h);
        }
        return new ArrayList<>(results);
    }
```

### 🧩 Educative Approach

### **Optimized approach using sliding window**

The problem can be optimized using a sliding window approach. We use the [Rabin-Karp algorithm](https://www.educative.io/answers/what-is-the-rabin-karp-algorithm) that utilizes a sliding window with **rolling hash** for pattern matching.

Here’s the basic idea of the algorithm:

- We traverse the string by using a sliding window of length k*k*, which slides one character forward on each iteration.
- On each iteration, we compute the hash of the current k*k*length substring in the window.
- We check if the hash is already present in the set.
    - If it is, the substring is repeated, so we add it to the output.
    - Otherwise, the substring has not yet been repeated, so we add the computed hash to the set.
- We repeat the above process for all k*k*length substrings by sliding the window one character forward on each iteration.
- After all k*k*length substrings have been evaluated, we return the output.

There are multiple approaches for computing hash values, and the choice of the hash function can impact the algorithm’s time complexity. Let’s look at some approaches below.

### **Hashing and comparison in linear time**

Let’s use a simple hashing method that sums the ASCII code of characters present in a window.

Consider the sequence ACTCT*ACTCT* with k=2*k*=2.

1. Initially, the sequence in the window is AC*AC* and its hash value is:
    
    H(AC)=65+67=132*H*(*AC*)=65+67=132
    
    Since the above hash value has not been repeated yet, we add this hash value to the set and slide the window one character forward.
    
2. The sequence in the window is now CT*CT*. To compute the hash value of CT*CT*, the ASCII of A*A* will be removed from the previous hash value and the ASCII of T*T* will then be added:
    
    H(CT)=132−65+84=151*H*(*CT*)=132−65+84=151
    
    Since the above hash value has not been repeated yet, we add this hash value to the set and slide the window one character forward.
    
3. The sequence in the window is now TC*TC*. To compute the hash value of TC*TC*, the ASCII of C*C* will be removed from the previous hash value and then again added:
    
    H(TC)=151−67+67=151*H*(*TC*)=151−67+67=151
    
    Here, we have the same hash value but different sequences—CT*CT* and TC*TC*. This means that if a hash value is already present in the set, we need to compare the corresponding sequences as well to confirm if they are identical. In this case, they are not, so we add this hash value to the set and slide the window one character forward.
    
4. The sequence in the window is now CT*CT*. To compute the hash value of CT*CT*, the ASCII of T*T* will be removed from the previous hash value and then again added:
    
    H(CT)=151−84+84=151*H*(*CT*)=151−84+84=151
    
    Here we have the same hash value, so we compare the two sequences. Since they are identical, the sequence has been repeated and is therefore added to the output.
    

Computing the hash value and then comparing the strings if the hashes are equal will take linear time, O(k)*O*(*k*). In the worst case, the comparisons will occur after each slide, which will make the running time the same as that of the naive approach, which is O((n−k+1)×k)*O*((*n*−*k*+1)×*k*).

### **Hashing and comparison in constant time**

We need a hash function that helps us achieve constant-time hashing. For this purpose, we use the **polynomial rolling hash** technique:

H=c1ak−1+c2ak−2+...+ciak−i+...+ck−1a1+cka0*H*=*c*1*ak*−1+*c*2*ak*−2+...+*ciak*−*i*+...+*ck*−1*a*1+*cka*0

Here, a*a* is a constant, c1,…,ck*c*1,…,*ck* are the characters in a sequence, and k*k* is the substring length. Since we only have 44 possible nucleotides, our a*a* would be 44. We also assign numeric values to the nucleotides, as shown in the table below:

[](data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQxIiBoZWlnaHQ9IjgxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMSIvPg==)

> Note: We use a value of 44 for the constant aa since this ensures that each nucleotide is assigned a unique value in the polynomial hash function. This reduces the number of hash collisions and helps reduce the randomness in the behaviour of the hash function.
> 
> 
> It is not necessary to set the constant a*a* equal to 44. In fact, this choice is somewhat arbitrary and can be any number that is greater than or equal to the number of nucleotides. The idea is to choose a value that is large enough to avoid hash collisions while still being relatively small, so as to minimize the risk of arithmetic overflow.
> 

> Example: The polynomial hash value for the sequence ATGATG will be
> 
> 
> H(ATG)=(1×42)+(4×41)+(3×40)=35*H*(*ATG*)=(1×42)+(4×41)+(3×40)=35
> 

Consider the same sequence ACTCT*ACTCT* with k=2*k*=2.

1. Initially, the sequence in the window is AC*AC*, and its hash value is:
    
    H(AC)=H(A)+H(C)*H*(*AC*)=*H*(*A*)+*H*(*C*)
    
    =(1×41)+(2×40)=(1×41)+(2×40)
    
    =6=6
    
    Since the above hash value has not been repeated yet, we add this hash value in the set and slide the window one character forward.
    
2. The sequence in the window is now CT*CT*. To compute the hash value of CT*CT*, we first need to remove the contribution of A*A* from the previous hash value:
    
    H(C)=H(AC)−H(A)=*H*(*C*)=*H*(*AC*)−*H*(*A*)=
    
    =6−(1×41)=6−(1×41)
    
    =2=2
    
    and then add the contribution of T*T*:
    
    H(CT)=H(C)+H(T)*H*(*CT*)=*H*(*C*)+*H*(*T*)
    
    =2+(4×40)=2+(4×40)
    
    =6=6
    
    This can’t be right, since both AC*AC* and CT*CT* cannot yield the same hash value. Examining our work carefully, we notice that we are not correctly accounting for place values. So, we need to shift the remaining bases to the left by one position so that the hash corresponds to the new sliding window. We do this by multiplying the current hash value by the base value a=4*a*=4. This means that H(C)*H*(*C*) becomes 2×412×41 and H(T)*H*(*T*) becomes 4×404×40. After that, we add the contribution of the incoming character T*T* to get the new hash value for the current sliding window:
    
    H(CT)=[(H(AC)−H(A))×4]+H(T)*H*(*CT*)=[(*H*(*AC*)−*H*(*A*))×4]+*H*(*T*)
    
    H(CT)=[6−(1×41)]×4+(4×40)*H*(*CT*)=[6−(1×41)]×4+(4×40)
    
    =12=12
    
    Since this hash value has not been seen yet, we add it to the set and slide the window one character forward.
    
3. The sequence in the window is now TC*TC*. We compute the hash value of TC*TC* in the same way as explained above:
    
    H(TC)=([H(CT)−H(C)]×4)+H(C)*H*(*TC*)=([*H*(*CT*)−*H*(*C*)]×4)+*H*(*C*)
    
    =([H(CT)−(2×4)]×4)+H(C)=([*H*(*CT*)−(2×4)]×4)+*H*(*C*)
    
    =([12−8]×4)+2=([12−8]×4)+2
    
    =(4×4)+2=(4×4)+2
    
    =16+2=18=16+2=18
    
    Since this hash value has not been seen yet, we add it to the set and slide the window one character forward. As you can see, even though CT*CT* and TC*TC* contain the same characters, since their relative order is different, the respective hash values of the two strings are also different.
    
4. The sequence in the window is now CT*CT*. We compute the hash value of CT*CT* in the same way as explained above:
    
    H(CT)=[(H(TC)−H(T))×4]+H(T)*H*(*CT*)=[(*H*(*TC*)−*H*(*T*))×4]+*H*(*T*)
    
    =[(18−16)×4]+4=[(18−16)×4]+4
    
    =[2×4]+4=[2×4]+4
    
    =12=12
    
    This hash value is present in the set. Therefore, we add it to the output without checking if the sequences are identical.
    
    From the above two approaches, it is clear that we will be using the polynomial rolling hash function in our solution to compute the hash values of the k*k*-length substrings since this method skips the need to compare two sequences if their hash values are the same and, therefore, helps us achieve constant-time hashing and comparison.
    

```java
public static Set<String> findRepeatedSequences(String dna, int k) {
      
        int stringLength = dna.length();

        if (stringLength < k) {
            return new HashSet<String>();
        }

        Map<Character, Integer> mapping = new HashMap<>();
        mapping.put('A', 1);
        mapping.put('C', 2);
        mapping.put('G', 3);
        mapping.put('T', 4);

        int baseValue = 4;

        List<Integer> numbers = new ArrayList<>(Arrays.asList(new Integer[stringLength]));
        Arrays.fill(numbers.toArray(), 0);
        for (int i = 0; i < stringLength; i++) {
            numbers.set(i, mapping.get(dna.charAt(i)));
        }

        int hashValue = 0;

        Set<Integer> hashSet = new HashSet<>();
        Set<String> output = new HashSet<>();

        for (int i = 0; i < stringLength - k + 1; i++) {

            if (i == 0) {
                for (int j = 0; j < k; j++) {
                    hashValue += numbers.get(j) * (int) Math.pow(baseValue, k - j - 1);
                }
            } else {
                int previousHashValue = hashValue;
                hashValue = ((previousHashValue - numbers.get(i - 1) * (int) Math.pow(baseValue, k - 1)) * baseValue) + numbers.get(i + k - 1);
            }

            if (hashSet.contains(hashValue)) {
                output.add(dna.substring(i, i + k));
            }

            hashSet.add(hashValue);
        }
        return output;
      }

```