# 3. Longest Substring Without Repeating Characters

LeetCode URL: https://leetcode.com/problems/longest-substring-without-repeating-characters
Coding Pattern: Sliding Window
Company: Amazon, Google, Meta
Date Solved: February 21, 2025
Difficulty Level: Medium
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n)
Space Complexity: O(n)
Topic: Sliding Window

### 🐞 Problem Statement

Given a string `s`, find the length of the **longest substring** without duplicate characters.

**Example 1:**

```
Input: s = "abcabcbb"
Output: 3
Explanation: The answer is "abc", with the length of 3.
```

**Example 2:**

```
Input: s = "bbbbb"
Output: 1
Explanation: The answer is "b", with the length of 1.
```

**Example 3:**

```
Input: s = "pwwkew"
Output: 3
Explanation: The answer is "wke", with the length of 3.
Notice that the answer must be a substring, "pwke" is a subsequence and not a substring.
```

---

### 🧮 Approach / Algorithm Design

### **Approach 3: Sliding Window Optimized**

### **Intuition**

The above solution requires at most 2n steps. In fact, it could be optimized to require only n steps. Instead of using a set to tell if a character exists or not, we could define a mapping of the characters to its index. Then we can skip the characters immediately when we found a repeated character.

### **Algorithm**

The reason is that if*s*[*j*]have a duplicate in the range[*i*,*j*)with index*j*′, we don't need to increase*i*little by little. We can skip all the elements in the range[*i*,*j*′]and let*i*to be*j*′+1directly.

Here is a visualization of the above code.

[https://www.youtube.com/watch?v=40BznmYU9Hg](https://www.youtube.com/watch?v=40BznmYU9Hg)

### 🎯 LeetCode Official Solution

```java
public class Solution {
    public int lengthOfLongestSubstring(String s) {
        int n = s.length(), ans = 0;
        Map<Character, Integer> charToNextIndex = new HashMap<>(); // index after current character
        // try to extend the range [i, j]
        for (int j = 0, i = 0; j < n; j++) {
            if (charToNextIndex.containsKey(s.charAt(j))) {
                i = Math.max(charToNextIndex.get(s.charAt(j)), i);
            }
            ans = Math.max(ans, j - i + 1);
            charToNextIndex.put(s.charAt(j), j + 1);
        }
        return ans;
    }
}
```

### ⏳ Complexity Analysis

- Time complexity :*O*(*n*).
- Space complexity :*O*(*min*(*m*,*n*)). Same as the previous approach. We need*O*(*k*)space for the sliding window, where*k*is the size of the`Set`. The size of the Set is upper bounded by the size of the string*n*and the size of the charset/alphabet*m*.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:abcabcbb
Output:
```

**Example 2:**

```
Input:bbbbb
Output:
```

**Example 3:**

```
Input:pwwkew
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
    public int lengthOfLongestSubstring(String s) {
      Map<Character, Integer> map = new HashMap<>();
      int start = 0;
      int end = 0;
      int max = 0;
      int endIndex = s.length() - 1;
      int currentIndex = 0;
      while (currentIndex <= endIndex) {
        char currentChar = s.charAt(currentIndex);
        if (map.containsKey(currentChar)) {
          int prevIndex = map.get(currentChar);
          if (prevIndex >= start) {
            start = prevIndex + 1;
          }
        }
        end = currentIndex;
        max = Math.max(max, end - start + 1);
        map.put(currentChar, currentIndex);
        currentIndex++;
      }
      return max;
    }
}
```