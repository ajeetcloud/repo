# 658. Find K Closest Elements

LeetCode URL: https://leetcode.com/problems/find-k-closest-elements
Approach: Approach 1: Find closest with Binary Search & then use sliding window.
Approach 2: Try to find the left boundary of the window using Binary Search.
Coding Pattern: Modified Binary Search
Company: Amazon, Google
Date Solved: January 26, 2026
Difficulty Level: Medium
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(log(N) + k)
Space Complexity: O(1)
Topic: Binary Search, Sliding Window

### 🐞 Problem Statement

Given a **sorted** integer array `arr`, two integers `k` and `x`, return the `k` closest integers to `x` in the array. The result should also be sorted in ascending order.

An integer `a` is closer to `x` than an integer `b` if:

- `|a - x| < |b - x|`, or
- `|a - x| == |b - x|` and `a < b`

**Example 1:**

**Input:** arr = [1,2,3,4,5], k = 4, x = 3

**Output:** [1,2,3,4]

**Example 2:**

**Input:** arr = [1,1,2,3,4,5], k = 4, x = -1

**Output:** [1,1,2,3]

**Constraints:**

- `1 <= k <= arr.length`
- `1 <= arr.length <= 104`
- `arr` is sorted in **ascending** order.
- `104 <= arr[i], x <= 104`

---

### 🧮 Approach / Algorithm Design

### **Approach 1: Sort With Custom Comparator**

**Intuition**

This first approach is the most intuitive one that most people probably think of first - check every number in `arr` for its distance from `x` and sort the numbers by this criterion. Then, the answer will be the first `k` elements of our new sorted array.

**Algorithm**

1. Create a new array `sortedArr`, that is `arr` sorted with a custom comparator. The comparator should be `abs(x - num)` for each `num` in `arr`. Sorting the array in ascending order means that the first `k` elements will be the `k` closest elements to `x`.
2. We also have to sort the "sorted" array, since the problem wants our output in ascending order. Return the first `k` elements of `sortedArr`, sorted by value, in ascending order.

```java
 Collections.sort(sortedArr, (num1, num2) -> Math.abs(num1 - x) - Math.abs(num2 - x));
```

### **Approach 2: Binary Search + Sliding Window**

**Intuition**

Every time you see a problem that involves a sorted array, you should consider binary search. In the previous approach, we considered every single number from `arr` as a potential candidate for the final output. However, when `arr.length` is very large, and `k` is very small, we do not care about a vast majority of the numbers in `arr`, and we should avoid looking at them.

Let's start by finding the closest number to `x` in `arr`. Logically, the second closest number to `x` must be directly beside the first number, either to the left or right. Then, the third closest number to `x` must be either to the left of the first number or to the right of the second number. This pattern continues, and is true because the input is sorted.

Using two pointers, we can maintain a sliding window that will expand to contain the `k` closest elements to `x`. Let's use binary search to efficiently find the closest number to `x` in `arr`, and start our pointers there. Then, we should expand our window by moving the pointers either left or right depending on which number is closer to `x`.

**Algorithm**

1. As a base case, if `arr.length == k`, return `arr`.
2. Use binary search to find the index of the closest element to `x` in `arr`. Initailize two pointers `left` and `right`, with `left` set equal to this index, and `right` equal to this index plus one.
3. While the window's size is less than `k`, check which number is closer to `x`: `arr[left]` or `arr[right]`. Whichever pointer has the closer number, move that pointer towards the edge to include that element in our output.
4. Return the elements inside `arr` contained within the window defined between `left` and `right`.

**Complexity Analysis**

- Time complexity: *O*(log(*N*)+*k*).
    
    The initial binary search to find where we should start our window costs *O*(log(*N*)). Our sliding window initially starts with size 0 and we expand it one by one until it is of size `k`, thus it costs *O*(*k*) to expand the window.
    
- Space complexity: *O*(1)
    
    We only use integer variables `left` and `right` that are *O*(1) regardless of input size. Space used for the output is not counted towards the space complexity.
    

### **Approach 3: Binary Search To Find The Left Bound**

**Intuition**

We can actually find the bounds of our sliding window much faster - and independent of `k`! First of all, what is the biggest index the left bound could be? If there needs to be `k` elements, then the left bound's upper limit is `arr.length - k`, because if it were any further to the right, you would run out of elements to include in the final answer.

As demonstrated in Approach 2, binary search is typically used to find if an element exists or where an element belongs in a sorted array. The beauty of algorithms lies in how abstract they are - with some clever thinking, we can apply binary search in a unique way to move our `left` and `right` pointers closer and closer to the left bound of our answer.

Let's consider two indices at each binary search operation, the usual `mid`, and some index `mid + k`. The relationship between these indices is significant because **only one of them could possibly be in a final answer**. For example, if `mid = 2`, and `k = 3`, then `arr[2]` and `arr[5]` could not possibly both be in the answer, since that would require taking 4 elements `[arr[2], arr[3], arr[4], arr[5]]`.

This leads us to the question: how do we move our pointers `left` and `right`? If the element at `arr[mid]` is closer to `x` than `arr[mid + k]`, then that means `arr[mid + k]`, as well as every element to the right of it can never be in the answer. This means we should move our `right` pointer to avoid considering them. The logic is the same vice-versa - if `arr[mid + k]` is closer to `x`, then move the left pointer.

**Algorithm**

1. Initalize two variables to perform binary search with, `left = 0` and `right = len(arr) - k`.
2. Perform a binary search. At each operation, calculate `mid = (left + right) / 2` and compare the two elements located at `arr[mid]` and `arr[mid + k]`. If the element at `arr[mid]` is closer to `x`, then move the right pointer. If the element at `arr[mid + k]` is closer to `x`, then move the left pointer. Remember, the smaller element always wins when there is a tie.
3. At the end of the binary search, we have located the leftmost index for the final answer. Return the subarray starting at this index that contains `k` elements.

**Complexity Analysis**

Given *N* as the length of `arr`,

- Time complexity: *O*(log(*N*−*k*)+*k*).
    
    Although finding the bounds only takes *O*(log(*N*−*k*)) time from the binary search, it still costs us *O*(*k*) to build the final output.
    
    Both the Java and Python implementations require *O*(*k*) time to build the result. However, it is worth noting that if the input array were given as a list instead of an array of integers, then the Java implementation could use the `ArrayList.subList()` method to build the result in *O*(1) time. If this were the case, the Java solution would have an (extremely fast) overall time complexity of *O*(log(*N*−*k*)).
    
- Space complexity: *O*(1).
    
    Again, we use a constant amount of space for our pointers, and space used for the output does not count towards the space complexity.
    

### 🎯 LeetCode Official Solution

```java
class Solution {
    public List<Integer> findClosestElements(int[] arr, int k, int x) {
        // Initialize binary search bounds
        int left = 0;
        int right = arr.length - k;
        
        // Binary search against the criteria described
        while (left < right) {
            int mid = (left + right) / 2;
            if (x - arr[mid] > arr[mid + k] - x) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        
        // Create output in correct format
        List<Integer> result = new ArrayList<Integer>();
        for (int i = left; i < left + k; i++) {
            result.add(arr[i]);
        }
        
        return result;
    }
}
```

### ⏳ Complexity Analysis

Given *N* as the length of `arr`,

- Time complexity: *O*(log(*N*−*k*)+*k*).
    
    Although finding the bounds only takes *O*(log(*N*−*k*)) time from the binary search, it still costs us *O*(*k*) to build the final output.
    
    Both the Java and Python implementations require *O*(*k*) time to build the result. However, it is worth noting that if the input array were given as a list instead of an array of integers, then the Java implementation could use the `ArrayList.subList()` method to build the result in *O*(1) time. If this were the case, the Java solution would have an (extremely fast) overall time complexity of *O*(log(*N*−*k*)).
    
- Space complexity: *O*(1).
    
    Again, we use a constant amount of space for our pointers, and space used for the output does not count towards the space complexity.
    

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {

    // Binary Search To Find The Left Bound of the Window - more Optimal
    public List<Integer> findClosestElements(int[] arr, int k, int x) {

        List<Integer> result = new ArrayList<>();

        int startIndex = 0;
        int endIndex = arr.length - k - 1;

        while (startIndex <= endIndex) {
            int mid = startIndex + (endIndex - startIndex) / 2;

            if (x - arr[mid] <= arr[mid + k] - x) {
                endIndex = mid - 1; // try better case, use startIndex
            } 
            else {
                startIndex = mid + 1;
            }
        }
        for (int i = startIndex; i < startIndex + k; i++) {
            result.add(arr[i]);
        }
        return result;
    }

    // Binary Search + Sliding Window
    public List<Integer> findClosestElements1(int[] arr, int k, int x) {

        List<Integer> result = new ArrayList<>();

        int startIndex = 0;
        int endIndex = arr.length - 1;
        while (startIndex < endIndex) {
            int mid = startIndex + (endIndex - startIndex) / 2;
            if (arr[mid] >= x) {
                endIndex = mid;
            } else {
                startIndex = mid + 1;
            }
        }
        int closestIndex = startIndex;

        int i = closestIndex - 1;
        int j = closestIndex;
        // Sliding window solution
        while (j - i - 1 < k) {
            if (i < 0) {
                j++;
            } else if (j > arr.length - 1) {
                i--;
            } else {
                int left = arr[i];
                int right = arr[j];
                if (Math.abs(left - x) <= Math.abs(right - x)) {
                    i--;
                } else {
                    j++;
                }
            }
        }
        for (int start = i + 1; start < j; start++) {
            result.add(arr[start]);
        }

        return result;
    }
}
```