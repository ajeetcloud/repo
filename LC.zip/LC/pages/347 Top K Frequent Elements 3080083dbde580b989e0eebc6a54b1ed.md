# 347. Top K Frequent Elements

LeetCode URL: https://leetcode.com/problems/top-k-frequent-elements
Approach: Create a freqMap. Use a MinHeap, you can use the getter of Map as Comparator. Get number from Map’s keySet. Offer into Heap and Poll from Heap once more than K. After all processing, Heap has the results.
Coding Pattern: Top K Elements
Company: Amazon, Google, Meta
Date Solved: February 20, 2026
Difficulty Level: Medium
Files & media: https://drive.google.com/file/d/1EuQ_g1JQz2edTGZ3_iljbjmdNcS9g5Co/view?usp=sharing
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n log n)
Space Complexity: O(N + k)
Topic: Heap (Priority Queue)

### 🐞 Problem Statement

Given an integer array `nums` and an integer `k`, return *the* `k` *most frequent elements*. You may return the answer in **any order**.

**Example 1:**

**Input:** nums = [1,1,1,2,2,3], k = 2

**Output:** [1,2]

**Example 2:**

**Input:** nums = [1], k = 1

**Output:** [1]

**Example 3:**

**Input:** nums = [1,2,1,2,1,2,3,1,3,2], k = 2

**Output:** [1,2]

**Constraints:**

- `1 <= nums.length <= 105`
- `104 <= nums[i] <= 104`
- `k` is in the range `[1, the number of unique elements in the array]`.
- It is **guaranteed** that the answer is **unique**.

**Follow up:** Your algorithm's time complexity must be better than `O(n log n)`, where n is the array's size.

---

### 🧮 Approach / Algorithm Design

**Video Solution**

[https://drive.google.com/file/d/1EuQ_g1JQz2edTGZ3_iljbjmdNcS9g5Co/view?usp=sharing](https://drive.google.com/file/d/1EuQ_g1JQz2edTGZ3_iljbjmdNcS9g5Co/view?usp=sharing)

### **Approach 1: Heap**

Let's start from the simple [heap](https://en.wikipedia.org/wiki/Heap_(data_structure)) approach with O(*N*log*k*) time complexity. To ensure that O(*N*log*k*) is always less than O(*N*log*N*), the particular case *k*=*N* could be considered separately and solved in O(1) time.

**Algorithm**

- The first step is to build a hash map `element -> its frequency`. In Java, we use the data structure `HashMap`. Python provides a dictionary subclass `Counter` to initialize the hash map we need directly from the input array. This step takes O(*N*) time where `N` is a number of elements in the list.
- The second step is to build a heap of *size k using N elements*. To add the first `k` elements takes a linear time O(*k*) in the average case, and *O*(log1+log2+...+log*k*)=*O*(*logk*!)=O(*k*log*k*) in the worst case. It's equivalent to [heapify implementation in Python](https://hg.python.org/cpython/file/2.7/Lib/heapq.py#l16). After the first `k` elements we start to push and pop at each step, `N - k` steps in total. The time complexity of heap push/pop is O(log*k*) and we do it `N - k` times which means O((*N*−*k*)log*k*) time complexity. Adding both parts up, we get O(*N*log*k*) time complexity for the second step.
- The third and last step is to convert the heap into an output array. That could be done in O(*k*log*k*) time.

In Python, library `heapq` provides a method `nlargest`, which [combines the last two steps under the hood](https://hg.python.org/cpython/file/2.7/Lib/heapq.py#l203) and has the same O(*N*log*k*) time complexity.

![diff](https://leetcode.com/problems/top-k-frequent-elements/Figures/347_rewrite/summary.png)

- Time complexity : O(*N*+*N*log*k*) if *k*<*N* and O(1) in the particular case of *N*=*k*. That ensures time complexity to be better than O(*N*log*N*).
- Space complexity : O(*N*+*k*) to store the hash map with not more *N* elements and a heap with *k* elements.

### 🎯 LeetCode Official Solution

```java
class Solution {
    public int[] topKFrequent(int[] nums, int k) {
        // O(1) time
        if (k == nums.length) {
            return nums;
        }
        
        // 1. Build hash map: character and how often it appears
        // O(N) time
        Map<Integer, Integer> count = new HashMap();
        for (int n: nums) {
          count.put(n, count.getOrDefault(n, 0) + 1);
        }

        // init heap 'the less frequent element first'
        Queue<Integer> heap = new PriorityQueue<>(
            (n1, n2) -> count.get(n1) - count.get(n2));

        // 2. Keep k top frequent elements in the heap
        // O(N log k) < O(N log N) time
        for (int n: count.keySet()) {
          heap.add(n);
          if (heap.size() > k) heap.poll();    
        }

        // 3. Build an output array
        // O(k log k) time
        int[] top = new int[k];
        for(int i = k - 1; i >= 0; --i) {
            top[i] = heap.poll();
        }
        return top;
    }
}
```

### ⏳ Complexity Analysis

- Time complexity : O(*N*+*N*log*k*) if *k*<*N* and O(1) in the particular case of *N*=*k*. That ensures time complexity to be better than O(*N*log*N*).
- Space complexity : O(*N*+*k*) to store the hash map with not more *N* elements and a heap with *k* elements.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {

    // Bucket Sort Approach
    public int[] topKFrequent1(int[] nums, int k) {

        Map<Integer, Integer> freqMap = new HashMap<>();
        for (int num: nums) {
            freqMap.put(num, freqMap.getOrDefault(num, 0) + 1);
        }
        List<Integer>[] freqBuckets = new List[nums.length + 1];
        for (int i = 0; i < freqBuckets.length; i++) {
            freqBuckets[i] = new ArrayList<>();
        } 
        for (Map.Entry<Integer, Integer> entry: freqMap.entrySet()) {
            freqBuckets[entry.getValue()].add(entry.getKey()); 
        }
        List<Integer> flattened = new ArrayList<>();
        for (int i = freqBuckets.length - 1; i >= 0; i--) {
            for (int n: freqBuckets[i]) {
                flattened.add(n);
            }
        }
        int[] result = new int[k];
        for (int i = 0; i < k; i++) {
            result[i] = flattened.get(i);
        }
        return result;
    }

    // MinHeap Approach
    public int[] topKFrequent(int[] nums, int k) {

        if (k == nums.length) {
            return nums;
        }

        Map<Integer, Integer> freqMap = new HashMap<>();
        for (int num: nums) {
            freqMap.put(num, freqMap.getOrDefault(num, 0) + 1);
        }
        PriorityQueue<Integer> freqMinHeap = new PriorityQueue<>((a, b) -> Integer.compare(freqMap.get(a), freqMap.get(b)));
        
        for (int num: freqMap.keySet()) {
            freqMinHeap.offer(num);
            if (freqMinHeap.size() > k) {
                freqMinHeap.poll();
            }
        }
        int[] result = new int[k];
        int i = 0;
        while (!freqMinHeap.isEmpty()) {
            result[i++] = freqMinHeap.poll();
        }
        return result;
    }
}
```