# 162. Find Peak Element

LeetCode URL: https://leetcode.com/problems/find-peak-element
Approach: Return mid id left is smaller and right is smaller to it. Else if the right element is bigger, then go right, as the slope is increasing. If left is bigger than mid then go left as slope is decreasing.
Coding Pattern: Modified Binary Search
Company: Google, Meta
Date Solved: January 30, 2026
Difficulty Level: Medium
Files & media: https://drive.google.com/file/d/1SXbmjbWcOPIQRCKYgAjb8fSk6cZPAEGu/view?usp=sharing
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(log n)
Space Complexity: O(1)
Topic: Binary Search

### 🐞 Problem Statement

A peak element is an element that is strictly greater than its neighbors.

Given a **0-indexed** integer array `nums`, find a peak element, and return its index. If the array contains multiple peaks, return the index to **any of the peaks**.

You may imagine that `nums[-1] = nums[n] = -∞`. In other words, an element is always considered to be strictly greater than a neighbor that is outside the array.

You must write an algorithm that runs in `O(log n)` time.

**Example 1:**

```
Input: nums = [1,2,3,1]
Output: 2
Explanation: 3 is a peak element and your function should return the index number 2.
```

**Example 2:**

```
Input: nums = [1,2,1,3,5,6,4]
Output: 5
Explanation: Your function can return either index number 1 where the peak element is 2, or index number 5 where the peak element is 6.
```

**Constraints:**

- `1 <= nums.length <= 1000`
- `231 <= nums[i] <= 231 - 1`
- `nums[i] != nums[i + 1]` for all valid `i`.

---

### 🧮 Approach / Algorithm Design

**Video Solution**

[https://drive.google.com/file/d/1SXbmjbWcOPIQRCKYgAjb8fSk6cZPAEGu/view?usp=sharing](https://drive.google.com/file/d/1SXbmjbWcOPIQRCKYgAjb8fSk6cZPAEGu/view?usp=sharing)

### **Approach 1: Linear Scan**

In this approach, we make use of the fact that two consecutive numbers *nums*[*j*] and *nums*[*j*+1] are never equal. Thus, we can traverse over the *nums* array starting from the beginning. Whenever, we find a number *nums*[*i*], we only need to check if it is larger than the next number *nums*[*i*+1] for determining if *nums*[*i*] is the peak element. The reasoning behind this can be understood by taking the following three cases which cover every case into which any problem can be divided.

Case 1. All the numbers appear in a descending order. In this case, the first element corresponds to the peak element. We start off by checking if the current element is larger than the next one. The first element satisfies this criteria, and is hence identified as the peak correctly. In this case, we didn't reach a point where we needed to compare *nums*[*i*] with *nums*[*i*−1] also, to determine if it is the peak element or not.

![Graph](https://leetcode.com/problems/find-peak-element/Figures/162/Find_Peak_Case1.PNG)

Case 2. All the elements appear in ascending order. In this case, we keep on comparing *nums*[*i*] with *nums*[*i*+1] to determine if *nums*[*i*] is the peak element or not. None of the elements satisfy this criteria, indicating that we are currently on a rising slope and not on a peak. Thus, at the end, we need to return the last element as the peak element, which turns out to be correct. In this case also, we need not compare *nums*[*i*] with *nums*[*i*−1], since being on the rising slope is a sufficient condition to ensure that *nums*[*i*] isn't the peak element.

![Graph](https://leetcode.com/problems/find-peak-element/Figures/162/Find_Peak_Case2.PNG)

Case 3. The peak appears somewhere in the middle. In this case, when we are traversing on the rising edge, as in Case 2, none of the elements will satisfy *nums*[*i*]>*nums*[*i*+1]. We need not compare *nums*[*i*] with *nums*[*i*−1] on the rising slope as discussed above. When we finally reach the peak element, the condition *nums*[*i*]>*nums*[*i*+1] is satisfied. We again, need not compare *nums*[*i*] with *nums*[*i*−1]. This is because, we could reach *nums*[*i*] as the current element only when the check *nums*[*i*]>*nums*[*i*+1] failed for the previous((*i*−1)*th* element, indicating that *nums*[*i*−1]<*nums*[*i*]. Thus, we are able to identify the peak element correctly in this case as well.

![Graph](https://leetcode.com/problems/find-peak-element/Figures/162/Find_Peak_Case3.PNG)

**Complexity Analysis**

- Time complexity : *O*(*n*). We traverse the *nums* array of size *n* once only.
- Space complexity : *O*(1). Constant extra space is used.

### **Approach 2: Iterative Binary Search**

**Algorithm**

The binary search discussed in the previous approach used a recursive method. We can do the same process in an iterative fashion also. This is done in the current approach.

**Complexity Analysis**

- Time complexity : *O*(*log*2(*n*)). We reduce the search space in half at every step. Thus, the total search space will be consumed in *log*2(*n*) steps. Here, *n* refers to the size of *nums* array.
- Space complexity : *O*(1). Constant extra space is used.

### 🎯 LeetCode Official Solution

```java
public class Solution {
    public int findPeakElement(int[] nums) {
        int l = 0, r = nums.length - 1;
        while (l < r) {
            int mid = (l + r) / 2;
            if (nums[mid] > nums[mid + 1]) r = mid;
            else l = mid + 1;
        }
        return l;
    }
}
```

### ⏳ Complexity Analysis

- Time complexity : *O*(*log*2(*n*)). We reduce the search space in half at every step. Thus, the total search space will be consumed in *log*2(*n*) steps. Here, *n* refers to the size of *nums* array.
- Space complexity : *O*(1). Constant extra space is used.

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
    public int findPeakElement(int[] nums) {

        int startIndex = 0;
        int endIndex = nums.length - 1;

        while (startIndex <= endIndex) {

            int mid = startIndex + (endIndex - startIndex) / 2;
            boolean isLeftSmaller = (mid == 0) || (nums[mid] > nums[mid - 1]);
            boolean isRightSmaller = (mid == nums.length - 1) || (nums[mid] > nums[mid + 1]);

            if (isLeftSmaller && isRightSmaller) {
                return mid;
            } 
            else if (nums[mid + 1] > nums[mid]) {
                startIndex = mid + 1;
            } 
            else {
                endIndex = mid - 1;
            }
        }
        return -1;
    }
}
```