# 287. Find the Duplicate Number

LeetCode URL: https://leetcode.com/problems/find-the-duplicate-number
Approach: Use slow & fast pointer in 2 parts. 
1. Detect cycle and break.
2. Set fast pointer in beginning and move fast and slow with same speed(slow), till they reach the same point.
Coding Pattern: Fast & Slow Pointers
Company: Amazon, Apple, Google, Meta
Date Solved: February 19, 2025
Difficulty Level: Medium
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n)
Space Complexity: O(1)
Topic: Two Pointers

### 🐞 Problem Statement

Given an array of integers `nums` containing `n + 1` integers where each integer is in the range `[1, n]` inclusive.

There is only **one repeated number** in `nums`, return *this repeated number*.

You must solve the problem **without** modifying the array `nums` and using only constant extra space.

**Example 1:**

```
Input: nums = [1,3,4,2,2]
Output: 2
```

**Example 2:**

```
Input: nums = [3,1,3,4,2]
Output: 3
```

**Example 3:**

```
Input: nums = [3,3,3,3,3]
Output: 3
```

**Constraints:**

- `1 <= n <= 105`
- `nums.length == n + 1`
- `1 <= nums[i] <= n`
- All the integers in `nums` appear only **once** except for **precisely one integer** which appears **two or more** times.

**Follow up:**

- How can we prove that at least one duplicate number must exist in `nums`?
- Can you solve the problem in linear runtime complexity?

---

### 🧮 Approach / Algorithm Design

### **Approach 7: Floyd's Tortoise and Hare (Cycle Detection)**

**Intuition**

The idea is to reduce the problem to

[Linked List Cycle II](https://leetcode.com/problems/linked-list-cycle-ii/solution/):

> Given a linked list, return the node where the cycle begins.
> 

First of all, where does the cycle come from?

Let's use the function`f(x) = nums[x]`to construct the sequence:

`x, nums[x], nums[nums[x]], nums[nums[nums[x]]], ...`.

Each new element in the sequence is an element in nums at the index

of the*previous*element.

If one starts from`x = nums[0]`, such a sequence will produce a linked list

with a cycle.

> The cycle appears becausenumscontains duplicates. The duplicate node
> 
> 
> is a cycle entrance.
> 

Here is how it works:

![](https://leetcode.com/problems/find-the-duplicate-number/Figures/287/simple_cycle.png)

The example above is simple because the loop is small. Here is a

more interesting example

(special thanks to @[sushant_chaudhari](https://leetcode.com/sushant_chaudhari))

![](https://leetcode.com/problems/find-the-duplicate-number/Figures/287/complex_cycle.png)

Now the problem is to find the entrance of the cycle.

**Algorithm**

[Floyd's algorithm](https://en.wikipedia.org/wiki/Cycle_detection#Tortoise_and_hare)

consists of two phases and uses two pointers, usually called`tortoise`and`hare`.

**In phase 1**,`hare = nums[nums[hare]]`is twice as fast as

`tortoise = nums[tortoise]`. Since the hare goes fast,

it would be the first to enter the cycle and run around the cycle.

At some point, the tortoise enters the cycle as well, and since

it's moving slower the hare catches up to the tortoise at some*intersection*point.

Now phase 1 is over, and the tortoise has lost.

> Note that the intersection point is not the cycle entrance in the general case.
> 

![](https://leetcode.com/problems/find-the-duplicate-number/Figures/287/first_intersection.png)

To compute the intersection point, let's note that the hare has

traversed twice as many nodes as the tortoise,

*i.e.* 2*d*(tortoise)=*d*(hare), implying:

2(*F*+*a*)=*F*+*nC*+*a*, where*n*is some integer.

> Hence the coordinate of the intersection point isF+a=nC.
> 

**In phase 2**, we give the tortoise a second chance by slowing down the hare,

so that it now moves at the speed of tortoise:`tortoise = nums[tortoise]`,

`hare = nums[hare]`. The tortoise is back at the starting

position, and the hare starts from the intersection point.

![](https://leetcode.com/problems/find-the-duplicate-number/Figures/287/phase2.png)

Let's show that this time they meet at the cycle entrance after *F* steps.

- The tortoise started at zero, so its position after *F* steps is *F*.
- The hare started at the intersection point *F*+*a*=*nC*,
    
    so its position after F steps is
    
    *nC*+*F*, that is the same point as*F*.
    
- So the tortoise and the (slowed down) hare will meet at the entrance of the cycle.

**Complexity Analysis**

- Time Complexity:*O*(*n*)
- Space Complexity:*O*(1)

For a detailed analysis, please refer to [Linked List Cycle II](https://leetcode.com/problems/linked-list-cycle-ii/solution/#approach-2-floyds-tortoise-and-hare-accepted).

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
    public int findDuplicate(int[] nums) {
        
        // Find the intersection point of the two runners.
        int tortoise = nums[0];
        int hare = nums[0];
        
        do {
            tortoise = nums[tortoise];
            hare = nums[nums[hare]];
        } while (tortoise != hare);

        // Find the "entrance" to the cycle.
        tortoise = nums[0];
        
        while (tortoise != hare) {
            tortoise = nums[tortoise];
            hare = nums[hare];
        }

        return hare;
    }
}
```