# 215. Kth Largest Element in an Array

LeetCode URL: https://leetcode.com/problems/kth-largest-element-in-an-array
Approach: Create a MinHeap. Offer elements. If MinHeap size > k, poll at the end, you will get kth largest.
Coding Pattern: Top K Elements
Company: Amazon, Google, Meta
Date Solved: January 20, 2026
Difficulty Level: Medium
Files & media: https://drive.google.com/file/d/1GbPm1Z9yMaJ3__dxAICATgJY7Q3xaFNp/view?usp=sharing
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n log k)
Space Complexity: O(n)
Topic: Heap (Priority Queue)

### 🐞 Problem Statement

Given an integer array `nums` and an integer `k`, return *the* `kth` *largest element in the array*.

Note that it is the `kth` largest element in the sorted order, not the `kth` distinct element.

Can you solve it without sorting?

**Example 1:**

```
Input: nums = [3,2,1,5,6,4], k = 2
Output: 5
```

**Example 2:**

```
Input: nums = [3,2,3,1,2,4,5,5,6], k = 4
Output: 4
```

**Constraints:**

- `1 <= k <= nums.length <= 105`
- `104 <= nums[i] <= 104`

---

### 🧮 Approach / Algorithm Design

**Video Solution**

[https://drive.google.com/file/d/1GbPm1Z9yMaJ3__dxAICATgJY7Q3xaFNp/view?usp=sharing](https://drive.google.com/file/d/1GbPm1Z9yMaJ3__dxAICATgJY7Q3xaFNp/view?usp=sharing)

### **Approach: Min-Heap**

**Intuition**

A heap is a very powerful data structure that allows us to efficiently find the maximum or minimum value in a dynamic dataset.

If you are not familiar with heaps, we recommend checking out the [Heap Explore Card](https://leetcode.com/explore/learn/card/heap/).

The problem is asking for the *kth* largest element. Let's push all the elements onto a min-heap, but pop from the heap when the size exceeds `k`. When we pop, the smallest element is removed. By limiting the heap's size to `k`, after handling all elements, the heap will contain exactly the *k* largest elements from the array.

![](https://leetcode.com/problems/kth-largest-element-in-an-array/Figures/215/1.png)

It is impossible for one of the green elements to be popped because that would imply there are at least *k* elements in the array greater than it. This is because we only pop when the heap's size exceeds `k`, and popping removes the smallest element.

After we handle all the elements, we can just check the top of the heap. Because the heap is holding the *k* largest elements and the top of the heap is the smallest element, the top of the heap would be the *kth* largest element, which is what the problem is asking for.

**Algorithm**

1. Initialize a min-heap `heap`.
2. Iterate over the input. For each `num`:
    - Push `num` onto the heap.
    - If the size of `heap` exceeds `k`, pop from `heap`.
3. Return the top of the `heap`.

### 🎯 LeetCode Official Solution

```java
class Solution {
    public int findKthLargest(int[] nums, int k) {
        PriorityQueue<Integer> heap = new PriorityQueue<>();
        for (int num: nums) {
            heap.add(num);
            if (heap.size() > k) {
                heap.remove();
            }
        }
        
        return heap.peek();
    }
}
```

### ⏳ Complexity Analysis

Given *n* as the length of `nums`,

- Time complexity: *O*(*n*⋅log*k*)
    
    Operations on a heap cost logarithmic time relative to its size. Because our heap is limited to a size of `k`, operations cost at most *O*(log*k*). We iterate over `nums`, performing one or two heap operations at each iteration.
    
    We iterate *n* times, performing up to log*k* work at each iteration, giving us a time complexity of *O*(*n*⋅log*k*).
    
    Because *k*≤*n*, this is an improvement on the previous approach.
    
- Space complexity: *O*(*k*)
    
    The heap uses *O*(*k*) space.
    

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```java
class Solution {
    public int findKthLargest(int[] nums, int k) {

        PriorityQueue<Integer> minHeap = new PriorityQueue<>();

        for (int num: nums) {
            minHeap.offer(num);
            if (minHeap.size() > k) {
                minHeap.poll();
            }
        }
        return minHeap.peek();
    }
}
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
class Solution {
    public int findKthLargest(int[] nums, int k) {

        PriorityQueue<Integer> minHeap = new PriorityQueue<>();

        for (int num: nums) {
            minHeap.offer(num);
            if (minHeap.size() > k) {
                minHeap.poll();
            }
        }
        return minHeap.peek();
    }
}
```