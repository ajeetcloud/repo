# 141. Linked List Cycle

LeetCode URL: https://leetcode.com/problems/linked-list-cycle
Approach: Use fast & slow pointer to check when they meet
Coding Pattern: Fast & Slow Pointers
Company: Amazon, Apple, Google
Date Solved: February 15, 2025
Difficulty Level: Easy
Files & media: https://drive.google.com/file/d/1MXmMrpVqlwTbytb5SuqrCTPwowpihnr7/view?usp=drive_link
Frequency of Revision: Monthly
Problem Progress: Completed
Time Complexity: O(n)
Space Complexity: O(1)
Topic: Linked List

### 🐞 Problem Statement

Given `head`, the head of a linked list, determine if the linked list has a cycle in it.

There is a cycle in a linked list if there is some node in the list that can be reached again by continuously following the `next` pointer. Internally, `pos` is used to denote the index of the node that tail's `next` pointer is connected to. **Note that `pos` is not passed as a parameter**.

Return `true` *if there is a cycle in the linked list*. Otherwise, return `false`.

**Example 1:**

![](https://assets.leetcode.com/uploads/2018/12/07/circularlinkedlist.png)

```
Input: head = [3,2,0,-4], pos = 1
Output: true
Explanation: There is a cycle in the linked list, where the tail connects to the 1st node (0-indexed).

```

**Example 2:**

![](https://assets.leetcode.com/uploads/2018/12/07/circularlinkedlist_test2.png)

```
Input: head = [1,2], pos = 0
Output: true
Explanation: There is a cycle in the linked list, where the tail connects to the 0th node.

```

**Example 3:**

![](https://assets.leetcode.com/uploads/2018/12/07/circularlinkedlist_test3.png)

```
Input: head = [1], pos = -1
Output: false
Explanation: There is no cycle in the linked list.

```

**Constraints:**

- The number of the nodes in the list is in the range `[0, 104]`.
- `105 <= Node.val <= 105`
- `pos` is `1` or a **valid index** in the linked-list.

**Follow up:** Can you solve it using `O(1)` (i.e. constant) memory?

### 🧮 Approach / Algorithm Design

**Video Solution**

[https://www.youtube.com/watch?v=W0UJyvcztJA](https://www.youtube.com/watch?v=W0UJyvcztJA)

Clarifying Notes

The video solution modifies the input by updating the value of the head. This is not recommended. It is better to create a new node to traverse the linked list, as shown in the solution below, so we can still access the head of the list.

---

## **Solution Article**

This article is for beginners. It introduces the following ideas: Linked List, Hash Table and Two Pointers.

---

### **Approach 1: Hash Table**

**Intuition**

To detect if a list is cyclic, we can check whether a node had been visited before. A natural way is to use a hash table.

**Algorithm**

We go through each node one by one and record each node's reference (or memory address) in a hash table. If the current node is `null`, we have reached the end of the list and it must not be cyclic. If current node’s reference is in the hash table, then return true.

```java
public class Solution {
    public boolean hasCycle(ListNode head) {
        Set<ListNode> nodesSeen = new HashSet<>();
        ListNode current = head;
        while (current != null) {
            if (nodesSeen.contains(current)) {
                return true;
            }
            nodesSeen.add(current);
            current = current.next;
        }
        return false;
    }
}
```

**Complexity analysis**

Let *n* be the total number of nodes in the linked list.

- Time complexity : *O*(*n*).
    
    We visit each of the *n* elements in the list at most once. Adding a node to the hash table costs only *O*(1) time.
    
- Space complexity: *O*(*n*).
    
    The space depends on the number of elements added to the hash table, which contains at most *n* elements.
    

### **Approach 2: Floyd's Cycle Finding Algorithm**

**Intuition**

Imagine two runners running on a track at different speed. What happens when the track is actually a circle?

**Algorithm**

The space complexity can be reduced to *O*(1) by considering two pointers at **different speed** - a slow pointer and a fast pointer. The slow pointer moves one step at a time while the fast pointer moves two steps at a time.

If there is no cycle in the list, the fast pointer will eventually reach the end and we can return false in this case.

Now consider a cyclic list and imagine the slow and fast pointers are two runners racing around a circle track. The fast runner will eventually meet the slow runner. Why? Consider this case (we name it case A) - The fast runner is just one step behind the slow runner. In the next iteration, they both increment one and two steps respectively and meet each other.

How about other cases? For example, we have not considered cases where the fast runner is two or three steps behind the slow runner yet. This is simple, because in the next or next's next iteration, this case will be reduced to case A mentioned above.

```java
public class Solution {
    public boolean hasCycle(ListNode head) {
        if (head == null) {
            return false;
        }

        ListNode slow = head;
        ListNode fast = head.next;
        while (slow != fast) {
            if (fast == null || fast.next == null) {
                return false;
            }
            slow = slow.next;
            fast = fast.next.next;
        }
        return true;
    }
}
```

**Complexity analysis**

- Time complexity : *O*(*n*).
    
    Let us denote *n* as the total number of nodes in the linked list. To analyze its time complexity, we consider the following two cases separately.
    
    - ***List has no cycle:***
        
        The fast pointer reaches the end first and the run time depends on the list's length, which is *O*(*n*).
        
    - ***List has a cycle:***
        
        We break down the movement of the slow pointer into two steps, the non-cyclic part and the cyclic part:
        
        1. The slow pointer takes "non-cyclic length" steps to enter the cycle. At this point, the fast pointer has already reached the cycle. Number of iterations=non-cyclic length=*N*
        2. Both pointers are now in the cycle. Consider two runners running in a cycle - the fast runner moves 2 steps while the slow runner moves 1 steps at a time. Since the speed difference is 1, it takes difference of speeddistance between the 2 runners loops for the fast runner to catch up with the slow runner.As the distance is at most cyclic length K - 1 and the speed difference is 1, we conclude that
            
            Number of iterations=at most cyclic length K - 1.
            
    
    Therefore, the worst case time complexity is *O*(*N*+*K*), which is *O*(*n*).
    
- Space complexity : *O*(1).
    
    We only use two nodes (slow and fast) so the space complexity is *O*(1).
    

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```cpp
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```java
public class Solution {
    public boolean hasCycle(ListNode head) {
      if (head == null) {
        return false;
      }
      ListNode slow = head;
      ListNode fast = head.next;
      while (fast != null && fast.next != null) {
        if (fast == slow) {
          return true;
        }
        slow = slow.next;
        fast = fast.next.next;
      }
      return false;
    }
}
```