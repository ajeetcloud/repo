# Circular array

LeetCode URL: https://leetcode.com/problems/circular-array-loop/description/

### 🐞 Problem Statement

---

### 🧮 Approach / Algorithm Design

# **Solution: Circular Array Loop**

## **Statement**

We are given a circular array of non-zero integers, `nums`, where each integer represents the number of steps to be taken either forward or backward from its current index. Positive values indicate forward movement, while negative values imply backward movement. When reaching either end of the array, the traversal wraps around to the opposite end.

The input array may contain a cycle, which is a sequence of indexes characterized by the following:

- The sequence starts and ends at the same index.
- The length of the sequence is at least two.
- The loop must be in a single direction, forward or backward.

> Note: A cycle in the array does not have to originate at the beginning. It may begin from any point in the array.
> 

Your task is to determine if `nums` has a cycle. Return TRUE if there is a cycle. Otherwise return FALSE.

**Constraints:**

- 1≤1≤ `nums.length` ≤103
    
    ≤103
    
- −5000≤−5000≤ `nums[i]` ≤5000
    
    ≤5000
    
- `nums[i]` !=0
    
    !=0
    

## **Solution**

So far, you’ve probably brainstormed some approaches and have an idea of how to solve this problem. Let’s explore some of these approaches and figure out which to follow based on considerations such as time complexity and implementation constraints.

### **Naive approach**

The naive approach involves iterating through each element of the input array. In each iteration, we start from the current element and check for cycles in both forward and backward directions. We also keep an additional array to track visited elements. If a cycle is detected during this process, we return TRUE. However, if the direction of the cycle changes at any point, we’ll move to the next iteration. We’ll repeat this until we find the cycle or traverse the complete array.

For each element in the outer loop, there is an inner loop that explores potential cycles, resulting in a time complexity of O(n2)*O*(*n*2). The space complexity is O(n)*O*(*n*) because we use extra space to keep track of the visited elements. This makes it an inefficient approach for large input arrays.

### **Optimized approach using fast and slow pointers**

We can use the fast and slow pointers technique, where traversing at different speeds enables efficient cycle detection. Comparing the signs of values during traversal facilitates correct navigation in both forward and backward directions within the array.

For each element of the array, two pointers, initialized at that specific element, traverse the array, with one taking one step at a time and the other advancing by two steps. The position of each pointer for the next step is determined by the value it is currently pointing to. If any movement results in the pointer pointing to a value with a different sign (indicating a change in direction) or pointing to the same index it was previously pointing to (indicating a self-loop), move to the next element of the array. Do the same if the fast pointer has reached the end of the linked list and no cycle is detected. However, if there’s a cycle, both pointers eventually catch up. This is because, in the non-cyclic part, the distance between them increases by one index in each iteration. However, upon entering the cyclic part, the fast pointer rapidly closes the gap on the slow pointer, decreasing the distance by one index in each iteration until they meet.

Let's see the workflow of the algorithm. The algorithm involves iterating through each index of `nums`. For every index, `i`, perform the following steps:

1. Initialize `fast` and `slow` pointers to the current index `i`.
2. Move the `slow` pointer, either forward or backward, depending on the current value it is pointing to, `nums[i]`. For example, if the value is −3, the `slow` pointer is moved three indexes backward. Similarly, if the value is 2, the `slow` pointer is moved two indexes forward.
3. Now, check if a valid cycle can be formed. For this, we have two primary checks:If any of the conditions above fail, move to step 4.
    1. If the index of the new value pointed to by `slow` is the same as the index of the previous value pointed to by `slow`, that is, the pointer is forming a self-loop, then the next iteration starts.
    2. Observe the sign of the previous value pointed to by `slow` and the sign of the new value it points to. If both values have different signs, that is, the pointer is not moving in a single direction, then the next iteration starts.
4. Move the `fast` pointer twice in a similar fashion, and after every move, check for the validity of the cycle using the same checks as above. If a valid cycle can’t be formed, move to the next index of `nums`.
5. Now, check for the existence of the cycle. If the slow and fast pointers meet at the same index, a cycle is detected. Return TRUE in this case. Otherwise, continue moving the pointers until we determine whether or not a cycle exists.

> Note: We only move to the next index if a valid cycle cannot be formed with the current index.
> 

If no cycle is detected for any index, return FALSE.

Here’s the demonstration of the steps above:

Let’s look at the code for this solution below:

### **Solution summary**

To recap, the solution to this problem can be divided into the following parts:

1. Move the slow pointer *x* steps forward/backward, where *x* is the value at the *ith* index of the array.
2. Move the fast pointer *x* steps forward/backward, where *x* is the value at *ith* index. Then, move fast pointer *y* steps forward/backward, where *y* is the value at *xth* index.
3. Return TRUE when both pointers meet at the same point.
4. If the direction changes after moving the slow or fast pointer or taking a step, return to the same location, then follow the steps above for the next element of the array.
5. Return FALSE if we have traversed every element of the array without finding a loop.

### **Time complexity**

The outer loop iterates through each element in the input array, contributing O(n)*O*(*n*) to the time complexity. Within this loop, there is a while loop that may iterate up to O(n)*O*(*n*) times in the worst case. This is because it advances pointers until a cycle is detected or the end of the array is reached. Therefore, in the worst-case scenario, where the while loop iterates through the entire array to detect a cycle, the total time complexity of this solution becomes O(n2)*O*(*n*2).

### **Space complexity**

We are not using any extra space in this algorithm. Therefore, the space complexity of the provided solution is O(1)*O*(1).

<aside>
💡

Key Insights Here

</aside>

---

### 📟 Your Logical Code

```cpp
// Your Logical Code goes here
```

---

### 🔁 Dry Run / Pseudo Code

---

### 📝 Explanation / Retrospective

---

### 🔍 Test Cases

**Example 1:**

```
Input:
Output:
```

**Example 2:**

```
Input:
Output:
```

**Example 3:**

```
Input:
Output:
```

---

### 🧩 Diagrams / Drawings (Optional)

---

### ✅ LeetCode Accepted Solution

```cpp
// LeetCode accepted Code goes here
```